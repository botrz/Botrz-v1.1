# -*- coding: utf-8 -*-
#Self Bot Premium Versi Jtbv1.3
from LineAPI.linepy import *
from LineAPI.akad.ttypes import Message
from LineAPI.akad.ttypes import ContentType as Type
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from threading import Thread
from thrift import transport, protocol, server
from time import sleep
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from googletrans import Translator
from humanfriendly import format_timespan, format_size, format_number, format_length
from threading import Thread
from line_notify import LineNotify
import time, random, sys, json, pafy, codecs, threading, glob, re, string, os, requests, six, ast, pytz, urllib, urllib3, urllib.parse, traceback, atexit, html5lib, humanize
_session = requests.session

#client = LINE()
ACCESS_TOKEN = "EcqsoNkOBqy7N1okmb04U4GrZfjjhtivkgQh3c5CTOv"
notify = LineNotify(ACCESS_TOKEN)
#notify.send("Hello World !") #Send Text Message
client = LINE()
clientMid = client.profile.mid
clientProfile = client.getProfile()
clientProfile = client.profile
clientSettings = client.getSettings()
mid = [clientMid]
clientMID = [clientMid]
clientPoll = OEPoll(client)
botStart = time.time()

Owner = [clientMid,"u4033ea77038ab1a6ec89c42fe317f7ab"]
owner = (clientMid,"u4033ea77038ab1a6ec89c42fe317f7ab")
admin = [clientMid,"u4033ea77038ab1a6ec89c42fe317f7ab"]
Bots = [mid]
#==============================================================================#


temp_flood = {}
msg_dict = {}
unsendchat = {}
msg_image={}
msg_video={}
msg_sticker={}
msg_waktu={}
offbot = []
player = []
set1=[]
set2=[]
player1=[]
player2=[]
real=[]

settings = {
    "userAgent": ['Mozilla/5.0 (Windows NT 6.2; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1667.0 Safari/537.36'],
    "selfbot" : True,
    "addPict" : True,
    "addSticker": {
        "status": False,
        "name": ""
    },
    "expire" : True,
    "time": time.time(),
    "flood": 0,
    "temp_flood" : False,
    "leave": True,
    "autoAdd": True,
    "autoJoin": True,
    "autoCancel": {"on":True,"members":5},
    "autoLeave": False,
    "autoRead": False,
    "autoRespon": False,
    "autoJoinTicket": True,
    "checkContact": False,
    "checkPost": False,
    "checkSticker": False,
    "changePictureProfile": False,
    "userMentioned": {},
    "Welcome": False,
    "WelcomeMessage": False,
    "siderMessage1": "Hey @! sider mulu jomblo ya (｡-_-｡)",
    "siderMessage2": "Halo @! sini dong gabung chat ఠ_ఠ",
    "siderMessage3": "Hi @! join chat please (╥﹏╥)",
    "autoAddMessage": "This is Bot Public By alfianbisma\n\nThanks @!,  for add me as a friends\n\nalfianbisma Gans In Here http://line.me/ti/p/~mr.sider",
    "commentPost": "Autolike by alfianbisma\nhttp://line.me/ti/p/~mr.sider\n\nSupport by Team DFB Bot",
    "wcMsg":False,
    "botMute": [],
    "botOff": [],
    "changeProfileVideo": {
        "picture": "",
        "stage": 2,
        "status": False,
        "video": ""
    },
    "addPict": {
       "name": "",
       "status":False,
    },
    "text1": "", 
    "text2": "", 
    "text3": "", 
    "image": {
        "imagetomis": [],
    }, 
    "changeGroupPicture": [],
    "keyCommand": "",
    "myProfile": {
        "displayName": "",
        "coverId": "",
        "pictureStatus": "",
        "statusMessage": "",
        "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
    },
    "mimic": {
        "copy": False,
        "status": False,
        "target": {}
    },
    "setKey": False,
    "unsendMessage": False
}

read = {
    "ROM": {},
    "readPoint": {},
    "readMember": {},
    "readTime": {}
}

dts = {
    "a": "idul fitri",
    "b": "paskah",
    "c": "imlek",
    "d": "natal",
    "player": [
        "u4f738fffa6cdf2d665620c6ae192e012",
        "u4033ea77038ab1a6ec89c42fe317f7ab",
        "ud9394137b0474f50c96d920f0577a3f3",
        "u61a75c02453154b7b216eb3912a77ff9",
        "u56ced377df8283bdb78db4baeacd4169",
        "u762f1b6a59d77f4dc14c5dff161da319",
        "uad20b260b7eed5b37cad0b187c961046",
        "u37e38ce85c1170b60e6647663c1743d6"
    ],
    "score": {
        "u37e38ce85c1170b60e6647663c1743d6": {
            "mid": "u37e38ce85c1170b60e6647663c1743d6",
            "sc": 0
        },
        "u4033ea77038ab1a6ec89c42fe317f7ab": {
            "mid": "u4033ea77038ab1a6ec89c42fe317f7ab",
            "sc": 4
        },
        "u4f738fffa6cdf2d665620c6ae192e012": {
            "mid": "u4f738fffa6cdf2d665620c6ae192e012",
            "sc": 1000
        },
        "u56ced377df8283bdb78db4baeacd4169": {
            "mid": "u56ced377df8283bdb78db4baeacd4169",
            "sc": 1
        },
        "u61a75c02453154b7b216eb3912a77ff9": {
            "mid": "u61a75c02453154b7b216eb3912a77ff9",
            "sc": 2
        },
        "u762f1b6a59d77f4dc14c5dff161da319": {
            "mid": "u762f1b6a59d77f4dc14c5dff161da319",
            "sc": 0
        },
        "uad20b260b7eed5b37cad0b187c961046": {
            "mid": "uad20b260b7eed5b37cad0b187c961046",
            "sc": 10
        },
        "ud9394137b0474f50c96d920f0577a3f3": {
            "mid": "ud9394137b0474f50c96d920f0577a3f3",
            "sc": 3
        }
    },
    "soal": "hari raya islam",
    "yes": "idul fitri"
}
 
wait = {
    "selfbot" : True,
    "leavemessage" : True,
    "MentionKick" : True,
    "Sider" : False,
    "unsendMessage" : False,
    "Mentionkick":False,
    "KickOn":False,
    "sticker": False,
    "quest": False,
    "suit": False,
    "suit1": False,
    "suit2": False,
    "owner":{},
    "admin":{},
}

suit = {
    "real": [],
    "score": {}
}

simi2 = {
    "simi-simi":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}

list_language = {
    "list_textToSpeech": {
        "id": "Indonesia",
        "af" : "Afrikaans",
        "sq" : "Albanian",
        "ar" : "Arabic",
        "hy" : "Armenian",
        "bn" : "Bengali",
        "ca" : "Catalan",
        "zh" : "Chinese",
        "zh-cn" : "Chinese (Mandarin/China)",
        "zh-tw" : "Chinese (Mandarin/Taiwan)",
        "zh-yue" : "Chinese (Cantonese)",
        "hr" : "Croatian",
        "cs" : "Czech",
        "da" : "Danish",
        "nl" : "Dutch",
        "en" : "English",
        "en-au" : "English (Australia)",
        "en-uk" : "English (United Kingdom)",
        "en-us" : "English (United States)",
        "eo" : "Esperanto",
        "fi" : "Finnish",
        "fr" : "French",
        "de" : "German",
        "el" : "Greek",
        "hi" : "Hindi",
        "hu" : "Hungarian",
        "is" : "Icelandic",
        "id" : "Indonesian",
        "it" : "Italian",
        "ja" : "Japanese",
        "km" : "Khmer (Cambodian)",
        "ko" : "Korean",
        "la" : "Latin",
        "lv" : "Latvian",
        "mk" : "Macedonian",
        "no" : "Norwegian",
        "pl" : "Polish",
        "pt" : "Portuguese",
        "ro" : "Romanian",
        "ru" : "Russian",
        "sr" : "Serbian",
        "si" : "Sinhala",
        "sk" : "Slovak",
        "es" : "Spanish",
        "es-es" : "Spanish (Spain)",
        "es-us" : "Spanish (United States)",
        "sw" : "Swahili",
        "sv" : "Swedish",
        "ta" : "Tamil",
        "th" : "Thai",
        "tr" : "Turkish",
        "uk" : "Ukrainian",
        "vi" : "Vietnamese",
        "cy" : "Welsh"
    },
    "list_translate": {    
        "af": "afrikaans",
        "sq": "albanian",
        "am": "amharic",
        "ar": "arabic",
        "hy": "armenian",
        "az": "azerbaijani",
        "eu": "basque",
        "be": "belarusian",
        "bn": "bengali",
        "bs": "bosnian",
        "bg": "bulgarian",
        "ca": "catalan",
        "ceb": "cebuano",
        "ny": "chichewa",
        "zh-cn": "chinese (simplified)",
        "zh-tw": "chinese (traditional)",
        "co": "corsican",
        "hr": "croatian",
        "cs": "czech",
        "da": "danish",
        "nl": "dutch",
        "en": "english",
        "eo": "esperanto",
        "et": "estonian",
        "tl": "filipino",
        "fi": "finnish",
        "fr": "french",
        "fy": "frisian",
        "gl": "galician",
        "ka": "georgian",
        "de": "german",
        "el": "greek",
        "gu": "gujarati",
        "ht": "haitian creole",
        "ha": "hausa",
        "haw": "hawaiian",
        "iw": "hebrew",
        "hi": "hindi",
        "hmn": "hmong",
        "hu": "hungarian",
        "is": "icelandic",
        "ig": "igbo",
        "id": "indonesian",
        "ga": "irish",
        "it": "italian",
        "ja": "japanese",
        "jw": "javanese",
        "kn": "kannada",
        "kk": "kazakh",
        "km": "khmer",
        "ko": "korean",
        "ku": "kurdish (kurmanji)",
        "ky": "kyrgyz",
        "lo": "lao",
        "la": "latin",
        "lv": "latvian",
        "lt": "lithuanian",
        "lb": "luxembourgish",
        "mk": "macedonian",
        "mg": "malagasy",
        "ms": "malay",
        "ml": "malayalam",
        "mt": "maltese",
        "mi": "maori",
        "mr": "marathi",
        "mn": "mongolian",
        "my": "myanmar (burmese)",
        "ne": "nepali",
        "no": "norwegian",
        "ps": "pashto",
        "fa": "persian",
        "pl": "polish",
        "pt": "portuguese",
        "pa": "punjabi",
        "ro": "romanian",
        "ru": "russian",
        "sm": "samoan",
        "gd": "scots gaelic",
        "sr": "serbian",
        "st": "sesotho",
        "sn": "shona",
        "sd": "sindhi",
        "si": "sinhala",
        "sk": "slovak",
        "sl": "slovenian",
        "so": "somali",
        "es": "spanish",
        "su": "sundanese",
        "sw": "swahili",
        "sv": "swedish",
        "tg": "tajik",
        "ta": "tamil",
        "te": "telugu",
        "th": "thai",
        "tr": "turkish",
        "uk": "ukrainian",
        "ur": "urdu",
        "uz": "uzbek",
        "vi": "vietnamese",
        "cy": "welsh",
        "xh": "xhosa",
        "yi": "yiddish",
        "yo": "yoruba",
        "zu": "zulu",
        "fil": "Filipino",
        "he": "Hebrew"
    }
}

try:
    with open("Log_data.json","r",encoding="utf_8_sig") as f:
        msg_dict = json.loads(f.read())
except:
    print("Couldn't read Log data")
    
settings["myProfile"]["displayName"] = clientProfile.displayName
settings["myProfile"]["statusMessage"] = clientProfile.statusMessage
settings["myProfile"]["pictureStatus"] = clientProfile.pictureStatus
coverId = client.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId

tagmeOpen = codecs.open("tag.json","r","utf-8")
tagme = json.load(tagmeOpen)

mulai = time.time()
#=======================================

def sendTemplate(to,data):
    data = json.dumps(data)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=data, headers=headers)

def templatesendSticker(to, image, text):
    data = {"messages":[{"type":"template","altText":clientProfile.displayName+" mengirim sticker","template":{"type":"image_carousel","columns":[{"imageUrl":image,"action":{"type":"uri","uri":text}}]}}]}
    sendTemplate(to, data)

def flexText(to, textnya, warna):
    data = {
        "messages": [
            {
                "type": "flex",
                "altText": "Alfian Bisma",
                "contents": {
                    "type": "bubble",
                    "body": {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                            {
                                "type": "text",
                                "text": textnya,
                                "wrap": True,
                                "color": warna,
                                "size": "sm"
                            }
                        ]
                    }
                }
            }
        ]
    }
    sendTemplate(to, data)

def imageHelp(to):
    data = {
      "messages": [
        {
  "type": "template",
  "altText": "this is a carousel template",
  "template": {
    "type": "image_carousel",
    "columns": [
                                                    {
                                                        "imageUrl": "https://wallpapersafari.com/w/wRg5Zz/",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Special",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Special"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://media.giphy.com/media/10i63vOstd7sYg/giphy.gif",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Media",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Media"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://lovehimehimedaisuki.com/ale/devloper.png",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Group",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Group"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://tse3.mm.bing.net/th?id=OGC.212f03ad714e0ffc3a5480ff2b81e9b2&pid=1.7&rurl=http%3A%2F%2F1.bp.blogspot.com%2F-ks5xzxFHOrQ%2FVBEMfkAvAbI%2FAAAAAAAAA_c%2FuPmP9aH3RDo%2Fs1600%2Fgambar-animasi-bergerak-lucu-keren.gif&ehk=cqgaJzTmMzlKwDcMjVeJiw",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Game",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Game"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://lovehimehimedaisuki.com/ale/devloper1.png",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Translate",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Translate"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://lovehimehimedaisuki.com/ale/devloper1.png",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Stickers",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Stickers"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://boteater.co/jpg-ki9jkntb.jpg",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Settings",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Settings"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://lovehimehimedaisuki.com/ale/devloper1.png",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Token",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Token"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://lovehimehimedaisuki.com/ale/devloper1.png",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "Helper",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Help2"
                                                        }
                                                    }, 
                                                    {
                                                        "imageUrl": "https://boteater.co/jpg-q4v25ch0.jpg",
                                                        "action": {
                                                            "type": "uri",
                                                            "label": "About",
                                                            "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=About"
                                                        }}]}}],}
    sendTemplate(to, data)
    
def buttonHelp(to, text1):
    data = {
      "messages": [
        {
  "type": "flex",
  "altText": "Profile",
  "contents": {
    "type": "bubble",
    "height": "sm",
    "style": "primary",
    "action": {
        "type": "uri",
        "label": text1,
        "uri": "line://nv/profilePopup/mid=u4033ea77038ab1a6ec89c42fe317f7ab"
    }}}]}
    sendTemplate(to, data)
    
def imageHelp1(to):
    data = {
      "messages": [
        {
  "type": "template",
  "altText": "Good morning",
  "template": {
    "type": "image_carousel",
    "columns": [
                                                    {
                                                        "imageUrl": "https://media.giphy.com/media/l0NwSvw3kQWZuUW8E/giphy.gif",
                                                        "action": {
                                                            "type": "uri",
                                                            "uri": "http://line.me/ti/p/~mr.sider"
                                                        }}]}}],}
    sendTemplate(to, data)
    
def imageHelp2(to):
    data = {
      "messages": [
        {
  "type": "template",
  "altText": "Token",
  "template": {
    "type": "carousel",
    "columns": [
                                                    {
                                                        "thumbnailImageUrl": "https://media.giphy.com/media/10i63vOstd7sYg/giphy.gif",
													       "title": "CHROME",
												           "text": "♻️ ListToken",
												           "actions": [
														       {
															       "type": "uri",
															       "label": "Token%20Chrome",
															       "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Token%20chrome"
														       },
														       {
															       "type": "uri",
															       "label": "Token%20Done",
															       "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Token%20done"
}
        												    ]
												       }
											       ]
										       }
									       }
								       ]
							       }
    sendTemplate(to, data)
    
def bctemplate(to, text2):
    contact = client.getContact("u4033ea77038ab1a6ec89c42fe317f7ab")
    data = {
      "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "Broadcast",
                                            "contents": {
                                                "type": "bubble",
                                                "styles": {
                                                        "hero": {
                                                            "seperator": True,
                                                            "align": "center"
                                                        },
                                                        "body": {
                                                            "backgroundColor": "#1C1C1C",
                                                        }, 
                                                        "footer": {
                                                            "backgroundColor": "#1C1C1C",
                                                            "separator": True
                                                        }
                                                    },
                                                "hero": {
                                                    "type": "image",
                                                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                                    "align": "left",
                                                    "size": "xl",
                                                    "aspectRatio": "11:8",
                                                    "aspectMode": "cover",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://ti/p/~mr.sider"
                                                    }
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Name",
                                                                            "color": "#00FFFF",
                                                                            "size": "sm",
                                                                            "flex": 1
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": text2,
                                                                            "color": "#FF4500",
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Bio",
                                                                            "color": "#00FFFF",
                                                                            "size": "sm",
                                                                            "flex": 1
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": text2,
                                                                            "color": "#FF4500",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "md",
                                                    "contents": [
                                                        {
                                                            "type": "button",
                                                            "height": "sm",
                                                            "style": "primary",
                                                            "action": {
                                                                "type": "uri",
                                                                "label": "CONTACT PERSON",
                                                                "uri": "line://nv/profilePopup/mid=u4033ea77038ab1a6ec89c42fe317f7ab"
                                                            }                                                   
                                                        },
                                                        {
                                                            "type": "spacer",
                                                            "size": "sm",
                                                        }
                                                    ],
                                                    "flex": 0
                                                }
                                            }
                                        }
        ]
    }
    sendTemplate(to, data)

def flexHelp(to, text1):
    data = {
      "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "Profile",
                                            "contents": 
                                                {
                                                "type": "bubble",
                                                "styles": {
                                                        "header": {
                                                            "backgroundColor": "#1C1C1C",
                                                        }, 
                                                        "body": {
                                                            "backgroundColor": "#1C1C1C",
                                                            "separator": True,
                                                            "separatorColor": "#000000"
                                                        }, 
                                                        "footer": {
                                                            "backgroundColor": "#1C1C1C",
                                                            "separator": True
                                                        }
                                                    },
                                                "header": {
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "align": "center",
                                                            "text": "FITUR",
                                                            "weight": "bold",
                                                            "color": "#F0F8FF",
                                                            "size": "xl", 
                                "action" : {
  "type" : "uri", "uri" : "https://line.me/ti/p/~mr.sider"} 
                                                        }
                                                    ]
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": text1,
                                                                            "color": "#F0F8FF",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                        },
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "sm",
                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "align": "center",
                                                                            "text": "➴ͥ ͣ ͫͫ͢૨ᴋɪɴɢs•🔰™̶̅✫",
                                                                            "iconUrl":'http://dl.profile.line-cdn.net/{}'.format(client.getContact("u4033ea77038ab1a6ec89c42fe317f7ab").pictureStatus),
                                                                            "color": "#F0F8FF",
                                                                            "wrap": True,
                                                                            "size": "sm"
                                                                        },
                                                        {
                                                            "type": "spacer",
                                                            "size": "sm",
                                                        }
                                                    ],
                                                    "flex": 0
                                                }
                                            }
                                        }
        ],
    }
    sendTemplate(to, data)
    
def flexHelp1(to, text2):
    data = {
      "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "➴ͥ ͣ ͫͫ͢૨ᴋɪɴɢs•🔰™̶̅✫",
                                            "contents": 
                                                {
                                                "type": "bubble",
                                                "styles": {
                                                        "header": {
                                                            "backgroundColor": "#F0F8FF",
                                                        }, 
                                                        "body": {
                                                            "backgroundColor": "#F0F8FF",
                                                            "separator": True,
                                                            "separatorColor": "#F0F8FF"
                                                        }, 
                                                        "footer": {
                                                            "backgroundColor": "#00FF00",
                                                            "separator": True
                                                        }
                                                    },
                                                "header": {
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "align": "center",
                                                            "text": "List Harga",
                                                            "weight": "bold",
                                                            "color": "#F0F8FF",
                                                            "size": "xl", 
                                "action" : {
  "type" : "uri", "uri" : "https://line.me/ti/p/~mr.sider"} 
                                                        }
                                                    ]
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": text2,
                                                                            "color": "#F0F8FF",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                        },
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "sm",
                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "align": "center",
                                                                            "text": "CONTACT PERSON",
                                                                            "color": "#F0F8FF",
                                                                            "wrap": True,
                                                                            "size": "sm"
                                                                        },
                                                        {
                                                            "type": "spacer",
                                                            "size": "sm",
                                                        }
                                                    ],
                                                    "flex": 0
                                                }
                                            }
                                        }
        ],
    }
    sendTemplate(to, data)

#=======================================

def restartBot():
    print ("[ INFO ] BOT RESTART")
    python = sys.executable
    os.execl(python, python, *sys.argv)
    
def logError(text):
    client.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))


def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
		
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                client.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]

def sendAnu(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@BacBac"
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'AGENT_NAME':'「Self Message」', 'AGENT_LINK': 'http://line.me/ti/p/~bacbac.id', 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + client.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def sendIan(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@BacBac"
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'AGENT_NAME':'「Help Message」', 'AGENT_LINK': 'line://ti/p/~bacbac.id{}'.format(client.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + client.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def sendMentionFooter(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@BacBac"
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'AGENT_NAME':'Dont Click!', 'AGENT_LINK': 'http://line.me/ti/p/~bacbac.id', 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + client.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)    
    #'AGENT_LINK': 'line://ti/p/~{}'.format(client.getProfile().userid),
    
def sendMessageWithFooter(to, text, name, url, iconlink):
        contentMetadata = {
            'AGENT_NAME': name,
            'AGENT_LINK': url,
            'AGENT_ICON': iconlink
        }
        return client.sendMessage(to, text, contentMetadata, 0)
    
def sendMessageWithFooter(to, text):
 client.reissueUserTicket()
 dap = client.getProfile()
 ticket = "http://line.me/ti/p/"+client.getUserTicket().id
 pict = "http://dl.profile.line-cdn.net/"+client.pictureStatus
 name = dap.displayName
 dapi = {"AGENT_ICON": pict,
     "AGENT_NAME": name,
     "AGENT_LINK": ticket
 }
 client.sendMessage(to, text, contentMetadata=client)
            
def sendMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@zeroxyuuki "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    
def uploadImage(ryn):
    url = 'https://errorteam.herokuapp.com/upload'
    path = client.downloadObjectMsg(ryn, saveAs='/root/generate.jpg')
    files = {"photo":open(path,'rb')}
    r = requests.post(url, files=files)
    data = r.json()
    return data["url"]

def bagasMention(to, text="",ps='', mids=[]):
    arrData = ""
    arr = []
    mention = "@BagasGans "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ''
        h = ''
        for mid in range(len(mids)):
            h+= str(texts[mid].encode('unicode-escape'))
            textx += str(texts[mid])
            if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
            else:slen = len(textx);elen = len(textx) + 13
            arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ''
        slen = len(textx)
        elen = len(textx) + 18
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    try:
        client.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "https://os.line.naver.jp/os/p/"+ps,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as e:
        client.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(to).displayName,'MSG_SENDER_ICON': 'https://os.line.naver.jp/os/p/'+to,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def khieMention(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@zeroxyuuki "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
     
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
 
def sendCarousel(data):
    data = json.dumps(data)
    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/SendMessage"
    headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 3S Build/MMB29M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/68.0.3440.85 Mobile Safari/537.36 Line/8.11.0'}
    headers['Content-Type'] = 'application/json'
    headers['Accept-Encoding'] = 'gzip,deflate'
    headers['Accept-Language'] = 'id-ID,en-US;q=0.9'
    headers['Connection'] = 'keep-alive'
    return requests.post(url, data=data, headers=headers)

def sendCarousel(data):
    url = "https://game.linefriends.com/jbp-lcs-ranking/lcs/SendMessage"
    data = data
    headers = {}
    headers['User-Agent'] = 'Mozilla/5.0 (Linux) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/67.0.3396.87 Mobile Safari/537.36 Line/8.10.1'
    headers['Content-Type'] = 'application/json'
    return requests.Session().post(url,data=json.dumps(data),headers=headers)
 
def youtubeMp4(to, link):
   r = requests.get("http://api.zicor.ooo/yt.php?url={}".format(str(link)))
   data = r.text
   data = json.loads(data)
   client.sendVideoWithURL(to, data["mp4"]["720"]) 
 
def sendSticker(to, version, packageId, stickerId):
    contentMetadata = {
        'STKVER': version,
        'STKPKGID': packageId,
        'STKID': stickerId
    }
    client.sendMessage(to, '', contentMetadata, 7)
   
def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = client.genOBSParams({'oid': clientMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        client.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))

def changeProfileVideo(to):
    if settings['changeProfileVideo']['picture'] == None:
        return client.sendMessage(to, "Foto tidak ditemukan")
    elif settings['changeProfileVideo']['video'] == None:
        return client.sendMessage(to, "Video tidak ditemukan")
    else:
        path = settings['changeProfileVideo']['video']
        files = {'file': open(path, 'rb')}
        obs_params = client.genOBSParams({'oid': client.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = client.server.postContent('{}/talk/vp/upload.nhn'.format(str(client.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return client.sendMessage(to, "Gagal update profile")
        path_p = settings['changeProfileVideo']['picture']
        settings['changeProfileVideo']['status'] = False
        client.updateProfilePicture(path_p, 'vp')

def sendLineMusic(to):
    contentMetadata = {
        'countryCode': 'ID',
        'i-installUrl': "line://ti/p/~{}".format(client.getProfile().userid),
        'a-packageName': 'com.spotify.music',
        'linkUri': "line://ti/p/~{}".format(client.getProfile().userid),
        'type': 'mt',
        'previewUrl':"http://dl.profile.line-cdn.net/{}".format(client.profile.pictureStatus),
        'a-linkUri': "line://ti/p/~{}".format(client.getProfile().userid),
        'text': client.profile.displayName,
        'id': 'mt000000000a6b79f9',
        'subText': client.profile.statusMessage
    }
    return client.sendMessage(to, client.profile.displayName, contentMetadata, 19)

def sendMusic(send_to,music_id,title,artist,thumbnail,link):
 client.sendMessage(send_to, '',
  {'text': title,
  'subText': artist,
  'id': music_id,
  'previewUrl': thumbnail,
  'linkUri': link,
  'i-linkUri': link,
  'a-linkUri': link,
  'i-installUrl': link,
  'a-installUrl': link,
  'a-packageName': 'jp.linecorp.linemusic.android',
  'type': 'mt',
  'countryCode': 'JP',
  'ORGCONTP': 'MUSIC'},
  19)    

def delExpire():
    if temp_flood != {}:
        for tmp in temp_flood:
            if temp_flood[tmp]["expire"] == True:
                if time.time() - temp_flood[tmp]["time"] >= 3*10:
                    temp_flood[tmp]["expire"] = False
                    temp_flood[tmp]["time"] = time.time()
                    try:
                        userid = "https://line.me/ti/p/~" + client.profile.userid
                        client.sendMessage(tmp, "Spam is Over,Now Bot Active Again!")
                    except Exception as error:
                        logError(error)
                        
def musik(to):
    contentMetadata={'previewUrl': "http://dl.profile.line-cdn.net/"+client.getContact(mid).picturePath, 'i-installUrl': 'http://itunes.apple.com/app/linemusic/id966142320', 'type': 'mt', 'subText': client.getContact(mid).statusMessage if client.getContact(mid).statusMessage != '' else 'creator By me |ID LINE|\nmr.sider', 'a-installUrl': 'market://details?id=jp.linecorp.linemusic.android', 'a-packageName': 'jp.linecorp.linemusic.android', 'countryCode': 'JP', 'a-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'i-linkUri': 'linemusic://open?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1', 'text': client.getContact(mid).displayName, 'id': 'mt000000000d69e2db', 'linkUri': 'https://music.me.me/launch?target=track&item=mb00000000016197ea&subitem=mt000000000d69e2db&cc=JP&from=lc&v=1','MSG_SENDER_ICON': "https://os.me.naver.jp/os/p/"+mid,'MSG_SENDER_NAME':  client.getContact(mid).displayName,}
    return client.sendMessage(to, client.getContact(mid).displayName, contentMetadata, 19)

def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def timeChange(secs):
	mins, secs = divmod(secs,60)
	hours, mins = divmod(mins,60)
	days, hours = divmod(hours,24)
	weeks, days = divmod(days,7)
	months, weeks = divmod(weeks,4)
	text = ""
	if months != 0: text += "%02d Bulan" % (months)
	if weeks != 0: text += " %02d Minggu" % (weeks)
	if days != 0: text += " %02d Hari" % (days)
	if hours !=  0: text +=  " %02d Jam" % (hours)
	if mins != 0: text += " %02d Menit" % (mins)
	if secs != 0: text += " %02d Detik" % (secs)
	if text[0] == " ":
		text = text[1:]
	return text
        
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]        

def cloneProfile(mid):
    contact = client.getContact(mid)
    if contact.videoProfile == None:
        client.cloneContactProfile(mid)
    else:
        profile = client.getProfile()
        profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus, saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + contact.pictureStatus + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = client.getProfileDetail(mid)['result']['objectId']
    client.updateProfileCoverById(coverId)

def backupProfile():
    profile = client.getContact(clientMID)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    settings['myProfile']['videoProfile'] = profile.videoProfile
    coverId = client.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def restoreProfile():
    profile = client.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    if settings['myProfile']['videoProfile'] == None:
        profile.pictureStatus = settings['myProfile']['pictureStatus']
        client.updateProfileAttribute(8, profile.pictureStatus)
        client.updateProfile(profile)
    else:
        client.updateProfile(profile)
        pict = client.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'], saveAs="tmp/pict.bin")
        vids = client.downloadFileURL( 'http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'] + '/vp', saveAs="tmp/video.bin")
        changeVideoAndPictureProfile(pict, vids)
    coverId = settings['myProfile']['coverId']
    client.updateProfileCoverById(coverId)


def sendMentionV2(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@zeroxyuuki "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def yt(query):
    with requests.session() as s:
        isi = []
        if query == "":
            query = "S1B nrik"
        s.headers['user-agent'] = 'Mozilla/5.0'
                     
        url    = 'http://www.youtube.com/results'
        params = {'search_query': query}
                     
        r    = s.get(url, params=params)
        soup = BeautifulSoup(r.content, 'html5lib')
                     
        for a in soup.select('.yt-lockup-title > a[title]'):
            if '&List' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=','')
                    isi += ['youtu.be' + b]
        return isi

def RECEIVE_MESSAGE(op):
    msg = op.message
    try:
        if msg.contentType == 0:
            try:
                if msg.to in settings['readPoint']:
                    if msg._from in settings["ROM"][msg.to]:
                        del settings["ROM"][msg.to][msg._from]
                else:
                    pass
            except:
                pass
        else:
            pass
          
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as error:
        print(error)
        print("\n\nRECEIVE_MESSAGE\n\n")
        return

def samMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@BacBac"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def userMentioned(to):
    try:
        mid = []
        for lu in settings["userMentioned"][to]:
            mid.append(lu)
        arrData = ""
        textx = "[ List User ]\n".format(str(len(mid)))
        arr = []
        no = 0 + 1
        for i in mid:
            textx += " {}. ".format(str(no))
            mention = "@x "
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            textx += "#{}x\n".format(str(settings["userMentioned"][to][i]))
            no += 1
        textx += "[ Total {} User ]".format(str(len(mid)))
        settings["userMentioned"][to] = {}
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
 
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d day %02d hours %02d Minute %02d Second' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d day %02d hours %02d Minute %02d second' % (days, hours, mins, secs)
   
def joox2(to,q,pl=""):
    try:
        url = "http://api.ntcorp.us/joox/search?q="+q
        r   = requests.get(url)
        data = r.json()
        for music in data['result']:
           finds = music['sid']
        urls = "http://api.ntcorp.us/joox/song_info?sid="+finds
        w = requests.get(urls)
        datax = w.json()
        a = "「Info Song」\n"
        sz = int(datax['result']['size'])
        a+="Title: %s" % datax['result']['song']
        a+='\nAlbum: %s' % datax['result']['album']
        a+='\nSize: '+format_size(sz)
        a+='\nLink: '+shorten(musik)
        client.sendImageWithURL(to,datax['result']['img'])
        client.sendMessage(to,a)
        client.sendAudioWithURL(to,musik)
    except:
        client.sendMessage(to,"Please cek your Sid >,<")
        print(traceback.format_exc())    
    
def helpmessage():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpMessage =   "╭─「Menu Help」" + "\n" + \
                    "│" + key + "Me" + "\n" + \
                    "│" + key + "Sp" + "\n" + \
                    "│" + key + "Media" + "\n" + \
                    "│" + key + "Token" + "\n" + \
                    "│" + key + "Special" + "\n" + \
                    "│" + key + "Mention" + "\n" + \
                    "│" + key + "Settings" + "\n" + \
                    "│" + key + "│More Menu│" + "\n" + \
                    "│" + key + "Runtime" + "\n" + \
                    "│" + key + "About" + "\n" + \
                    "│" + key + "Creator" + "\n" + \
                    "│" + key + "Chatowner:「Pesanmu」" + "\n" + \
                    "│" + key + "#Self On" + "\n" + \
                    "│" + key + "#Self Off" + "\n" + \
                    "╰「[JTB]ᎫϴᏦᎬᎡ ͲᎬᎪᎷ ᏴϴͲ」" 
    return helpMessage

def helpmedia():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpMedia =   "╭─「Help Media」" + "\n" + \
                    "│" + key + "Animequotes" + "\n" + \
                    "│" + key + "Artinama「Search」" + "\n" + \
                    "│" + key + "Artisifatnama「Search」" + "\n" + \
                    "│" + key + "Asking「Search」" + "\n" + \
                    "│" + key + "Bitcoin" + "\n" + \
                    "│" + key + "Brainly「Search」" + "\n" + \
                    "│" + key + "Creepypasta" + "\n" + \
                    "│" + key + "Deviantart「Search」" + "\n" + \
                    "│" + key + "Downloadyt「Url」" + "\n" + \
                    "│" + key + "Fmylife" + "\n" + \
                    "│" + key + "Fight" + "\n" + \
                    "│" + key + "Fscosplay「Query」" + "\n" + \
                    "│" + key + "Fsviloid「Query」" + "\n" + \
                    "│" + key + "Gift" + "\n" + \
                    "│" + key + "Harinasional 「Search」" + "\n" + \
                    "│" + key + "Image「Search」" + "\n" + \
                    "│" + key + "Imageart「Search」" + "\n" + \
                    "│" + key + "Instagram「Search」" + "\n" + \
                    "│" + key + "Raffle" + "\n" + \
                    "│" + key + "Raffle2" + "\n" + \
                    "│" + key + "Motivate" + "\n" + \
                    "│" + key + "Music「Search」" + "\n" + \
                    "│" + key + "Missing-text-text-text" + "\n" + \
                    "│" + key + "Neon:「Query」" + "\n" + \
                    "│" + key + "Samehadaku「Search」" + "\n" + \
                    "│" + key + "Stickerline「Search」" + "\n" + \
                    "│" + key + "Ssweb「Url」" + "\n" + \
                    "│" + key + "Themeline「Search」" + "\n" + \
                    "│" + key + "Timezone「Search」" + "\n" + \
                    "│" + key + "Topnews" + "\n" + \
                    "│" + key + "Top kaskus" + "\n" + \
                    "│" + key + "Wallpaper-hd「Search」" + "\n" + \
                    "│" + key + "Whois「Search」" + "\n" + \
                    "│" + key + "Ytdl「Url」" + "\n" + \
                    "│" + key + "Zodiaceng「Query」" + "\n" + \
                    "│" + key + "Zodiacind「Query」" + "\n" + \
                    "╰「[JTB]ᎫϴᏦᎬᎡ ͲᎬᎪᎷ ᏴϴͲ」"
    return helpMedia
    
def helpmedia1():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpMedia1 =   key + "• Animequotes" + "\n" + \
                    key + "• Artinama「Search」" + "\n" + \
                    key + "• Artisifatnama「Search」" + "\n" + \
                    key + "• Asking「Search」" + "\n" + \
                    key + "• Bitcoin" + "\n" + \
                    key + "• Brainly「Search」" + "\n" + \
                    key + "• Creepypasta" + "\n" + \
                    key + "• Deviantart「Search」" + "\n" + \
                    key + "• Downloadyt「Url」" + "\n" + \
                    key + "• Fmylife" + "\n" + \
                    key + "• Fight" + "\n" + \
                    key + "• Fscosplay「Query」" + "\n" + \
                    key + "• Fsviloid「Query」" + "\n" + \
                    key + "• Gift" + "\n" + \
                    key + "• Harinasional 「Search」" + "\n" + \
                    key + "• Image「Search」" + "\n" + \
                    key + "• Imageart「Search」" + "\n" + \
                    key + "• Instagram「Search」" + "\n" + \
                    key + "• Raffle" + "\n" + \
                    key + "• Raffle2" + "\n" + \
                    key + "• Motivate" + "\n" + \
                    key + "• Music「Search」" + "\n" + \
                    key + "• Missing-text-text-text" + "\n" + \
                    key + "• Neon:「Query」" + "\n" + \
                    key + "• Samehadaku「Search」" + "\n" + \
                    key + "• Stickerline「Search」" + "\n" + \
                    key + "• Ssweb「Url」" + "\n" + \
                    key + "• Themeline「Search」" + "\n" + \
                    key + "• Timezone「Search」" + "\n" + \
                    key + "• Topnews" + "\n" + \
                    key + "• Top kaskus" + "\n" + \
                    key + "• Wallpaper-hd「Search」" + "\n" + \
                    key + "• Whois「Search」" + "\n" + \
                    key + "• Ytdl「Url」" + "\n" + \
                    key + "• Zodiaceng「Query」" + "\n" + \
                    key + "• Zodiacind「Query」"
    return helpMedia1
    
def helpspecial1():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpSpecial1 =  key + "• Chat|Num|Msg" + "\n" + \
                    key + "• Exec「Query」" + "\n" + \
                    key + "• Leavegc「Num」" + "\n" + \
                    key + "• Like「Mention」" + "\n" + \
                    key + "• Infomem「Num」" + "\n" + \
                    key + "• Invitetogc「Num」" + "\n" + \
                    key + "• Openqr:Num" + "\n" + \
                    key + "• Setcomment:「Query」" + "\n" + \
                    key + "• Unsend「Num」" + "\n" + \
                    key + "• Hack Textnya「Mention」" + "\n" + \
                    key + "• Mentionme" + "\n" + \
                    key + "• Delmentionme"
    return helpSpecial1

def helpspecial2():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpSpecial2 =  "╭─「Help Special」" + "\n" + \
                    "│" + key + "Chat|Num|Msg" + "\n" + \
                    "│" + key + "Exec「Query」" + "\n" + \
                    "│" + key + "Leavegc「Num」" + "\n" + \
                    "│" + key + "Like「Mention」" + "\n" + \
                    "│" + key + "Infomem「Num」" + "\n" + \
                    "│" + key + "Invitetogc「Num」" + "\n" + \
                    "│" + key + "Openqr:Num" + "\n" + \
                    "│" + key + "Setcomment:「Query」" + "\n" + \
                    "│" + key + "Unsend「Num」" + "\n" + \
                    "│" + key + "Hack Textnya「Mention」" + "\n" + \
                    "│" + key + "Mentionme" + "\n" + \
                    "│" + key + "Delmentionme" + "\n" + \
                    "╰「[JTB]ᎫϴᏦᎬᎡ ͲᎬᎪᎷ ᏴϴͲ」"
    return helpSpecial2  

def helptoken():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpToken =  key + "• Token Chrome" + "\n" + \
                    key + "• Token Ios" + "\n" + \
                    key + "• Token Win" + "\n" + \
                    key + "• Token Mac" + "\n" + \
                    key + "• Token Win10"
    return helpToken
    
def helpprice():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpPrice =  key + "Open Sewa SelfBot Premium" + "\n" + \
                    key + "• Fitur:" + "\n" + \
                    key + "√ Template" + "\n" + \
                    key + "√ Footer" + "\n" + \
                    key + "√ Flex" + "\n" + \
                    key + "√ Image CoroUsel" + "\n" + \
                    key + "√ Cdual, Cvp, Ypp" + "\n" + \
                    key + "√ Fiture Lengkap" + "\n" + \
                    key + "√ Game" + "\n" + \
                    key + "√ Token No api" + "\n" + \
                    key + "Etc."
    return helpPrice
    
def helpsettings():
    if settings['setKey'] == True:
        key = settings['keyCommand']
    else:
        key = ''
    helpSettings =   key + "• AutoAdd「On/Off」" + "\n" + \
                    key + "• AutoJoin「On/Off」" + "\n" + \
                    key + "• AutoJoinTicket「On/Off」" + "\n" + \
                    key + "• AutoLeave「On/Off」" + "\n" + \
                    key + "• AutoRead「On/Off」" + "\n" + \
                    key + "• AutoRespon「On/Off」" + "\n" + \
                    key + "• CheckContact「On/Off」" + "\n" + \
                    key + "• CheckPost「On/Off」" + "\n" + \
                    key + "• CheckSticker「On/Off」" + "\n" + \
                    key + "• UnsendChat「On/Off」" + "\n" + \
                    key + "• Sider「On/Off」" + "\n" + \
                    key + "• Simi「On/Off」"
    return helpSettings

def clientBot(op):
    try:
        if op.type == 0:
            print ("[ 0 ] END OF OPERATION")
            return

        if op.type == 5:
            print ("[ 5 ] NOTIFIED ADD CONTACT")
            if settings["autoAdd"] == True:
                client.findAndAddContactsByMid(op.param1)
            bagasMention(op.param1, "{}".format(settings["autoAddMessage"]), "", [op.param1])
            
        if op.type == 13:
            print ("[ 13 ] NOTIFIED INVITE INTO GROUP")
            if clientMid in op.param3:
            	G = client.getGroup(op.param1)
            	if settings["autoJoin"] == True:
            		if settings["autoCancel"]["on"] == True:
            			if len(G.members) <= settings["autoCancel"]["members"]:
            				client.acceptGroupInvitation(op.param1)
            				sendMention(op.param1, "Maaf Kak @! Anggota Kurang Lebih Dari 5 Member 😕",[op.param2])
            				client.leaveGroup(op.param1)
            			else:
            				client.acceptGroupInvitation(op.param1)
            				sendMention(op.param1, "Halo @!\nThanks For Invite Me",[op.param2])
                

#######        if op.type == 15:
##########           print ("[ 15 ] NOTIFIED LEAVE GROUP")
########           if settings["leave"] == True:
#######               contact = client.getContact(msg._from)
####### ##          ##    client.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + client.getContact(op.param2).picturePath)
 #######              client.sendContact(op.param1, op.param2)
   ###########           sendMention(op.param1, "Yah @!, kenapa out kak :'(", [op.param2])

        if op.type == 17:
            print ("[ 17 ] NOTIFIED ACCEPT GROUP INVITATION")
            group = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            if settings["WelcomeMessage"] == True:
                sendMention(op.param1, op.param2, "「 Auto Tag 」\n•", "\n{}".format(str(settings["WelcomeMessage"])))
            

        if op.type in [22, 24]:
            print ("[ 22 And 24 ] NOTIFIED INVITE INTO ROOM & NOTIFIED LEAVE ROOM")
            if settings["autoLeave"] == True:
                sendMention(op.param1, "Oi asw @!,ngapain invite saya")
                client.leaveRoom(op.param1)
                
        if op.type == 26:
            print ('[25/26] NOTIFED RECIVED MESSAGE')
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    client.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 16:
                  if msg.toType in (2,1,0):
                     try:
                         mat = msg.contentMetadata["postEndUrl"].split('userMid=')[1].split('&postId=')
                         client.likePost(mat[0], mat[1], 1003)
                         client.createComment(mat[0], mat[1], "Autolike by alfianbisma")
                         client.sendReplyMessage(msg.id, to, "➥Like Success ♪")
                     except Exception as e:
                         client.sendMessage(msg.to, str(e))
                
        if op.type == 26:
            msg = op.message                    
            if msg.to in simi2["simi-simi"]:
                if simi2["simi-simi"][msg.to] == True:
                 try:
                      if msg.text is not None:
                         simi = msg.text
                         r = requests.get("https://api.eater.site/api/chatbot/?apikey=beta&question="+simi)
                         data = r.text
                         data = json.loads(data)
                         if data["code"] == 200:
                            client. sendReplyMessage(msg.id, msg.to, str(data["result"]["answer"]))
                 except Exception as error:
                     pass 

                      
        if op.type == 55:
            try:
                if cctv['cyduk'][op.param1]==True:
                    if op.param1 in cctv['point']:
                        Name = client.getContact(op.param2).displayName
                        if Name in cctv['sidermem'][op.param1]:
                            pass
                        else:
                                cctv['sidermem'][op.param1] += "\n> " + Name
                                if " " in Name:
                                    nick = Name.split(' ')
                                    if len(nick) == 2:
                                        sendMention(op.param1, "Hey @! betah banget jadi sider 😑",[op.param2])
                                        #client.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + client.getContact(op.param2).picturePath)
                                        summon(op.param1,[op.param2])
                                    else:
                                        sendMention(op.param1, "Hey @! sider mulu jomblo ya (｡-_-｡)",[op.param2])
                                        #client.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + client.getContact(op.param2).picturePath)
                                        summon(op.param1,[op.param2])
                                else:
                                    sendMention(op.param1, "Hey @! cie ketahuan sider ( ͡° ͜ʖ ͡°)",[op.param2])
                                    #client.sendImageWithURL(op.param1, "http://dl.profile.line-cdn.net" + client.getContact(op.param2).picturePath)
                                    summon(op.param1,[op.param2])
                    else:
                        pass
                else:
                    pass
            except:
                pass                  

        if op.type in [25,26]:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
            #if msg.toType == 0:
               if msg.toType == 0:
                  if sender != client.profile.mid:
                     to = sender
                     msg.to = sender
                  else:
                      to = receiver
                      msg.to = receiver
               elif msg.toType == 1:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 0:
                   if text is None:
                      return
                   else:
                        cmd = command(text)
                        if text.lower() == '#soal' or text.lower() =='soal':
                            if wait["selfbot"] == True:
                                if sender in dts['player']:
                                    wait["quest"]=True
                                    arg=['iman','tehnologi','seputardunia','kesehatan']
                                    link = 'http://arsygameapi.herokuapp.com/req/kat/{}'.format(random.choice(arg))
                                    req = requests.get(link)
                                    data = json.loads(req.text)
                                    dts['soal']=data["soal"]
                                    dts['yes']=data["jawaban"]["t"]
                                    dts['a']=data["jawaban"]["a"]
                                    dts['b']=data["jawaban"]["b"]
                                    dts['c']=data["jawaban"]["c"]
                                    dts['d']=data["jawaban"]["d"]
                                    ans=dts['soal']+'\n\na.{}\nb.{}\nc.{}\nd.{}\n\nChose >a or >b or >c or >d'.format(dts['a'],dts['b'],dts['c'],dts['d'])
                                    client.sendMessage(msg.to,str(ans))
                                else:
                                    sendMention(to, 'ketik {join} first \n> @!', [sender])
                        if text.lower() == 'game suit':
                            if wait["selfbot"] == True:
                                wait["suit"] = True
                                wait["quest"]=False
                                sendMention(to, 'Ketik join player 1 or join player 2\n> @!', [sender])
                        if text.lower() == "leaderboards suit":
                            try:
                                if sender in suit['real']:
                                    no = 0
                                    ls = '[ LeaderBoards ]\nType game : suit\n'
                                    for a in suit['real']:
                                        no =no+1
                                        kintil = client.getContact(a).displayName
                                        score = str(suit['score'][a]['sc'])
                                        ls += str(no)+'. '+kintil+' : '+score+'\n'
                                    ls += '\n     [ Creator rizal ]'
                                    client.sendReplyMessage(msg_id, to, str(ls))
                                    wait["quest"] = False
                                    wait["suit"] = False
                                else:
                                    sendMention(to, 'Game suit first \n> @!', [sender])
                            except Exception as e:
                                client.sendMessage(msg.to, str(e))
                        if wait["suit"] == True:
                            if text.lower() == 'join player 1':
                                if sender in player2:
                                    sendMention(to, 'Anda sudah join di player 2 jadi tidak bisa join lagi @!', [sender])
                                else:
                                    if len(player1) >= 1:
                                        client.sendMessage(msg.to, 'player 1 max 1 pemain')
                                    else:
                                        if sender in player1:
                                            sendMention(to, "Sudah Join @! Tunggu player 2", [sender])
                                        else:
                                            player1.append(sender)
                                            suit['real'].append(sender)
                                            suit['score'][sender]['sc']=0
                                            client.sendMessage(msg.to, "Ketik join player 2 untuk masuk ke player 2,Ketik #start untuk mulai")
                            if text.lower() == 'join player 2':
                                if sender in player1:
                                    sendMention(to, 'Anda sudah join di player 1 jadi tidak bisa join lagi @!', [sender])
                                else:
                                    if len(player2) >= 1:
                                        client.sendMessage(msg.to, 'player 2 max 1 pemain')
                                    else:
                                        if sender in player1:
                                            sendMention(to, "Sudah Join @! Tunggu player 1", [sender])
                                        else:
                                            player2.append(sender)
                                            suit['real'].append(sender)
                                            dts['score'][sender]['sc']=0
                                            client.sendMessage(msg.to, "Ketik join player 1 untuk masuk ke player 1,Ketik #start untuk mulai")
                            if text.lower() == '#start':
                                try:
                                    if sender in player1 or sender in player2:
                                        wait["quest"] = False
                                        client.sendMessage(player1[0], 'select your choose >gunting or >batu or >kertas')
                                        G = client.getGroup(msg.to)
                                        client.sendMessage(msg.to, 'check your pc to choose')
                                    else:
                                        client.sendMessage(msg.to, 'anda tidak dalam game')
                                except Exception as e:
                                    client.sendMessage(msg.to, str(e))
                            if text.lower().startswith(">"):
                                wait['suit1'] = True
                                if sender in player1:
                                    suit1 = text.lower().replace(">","")
                                    if suit1 == "kertas" or suit1 == "batu" or suit1 == "gunting":
                                        set1.append(suit1)
                                        client.sendMessage(sender, "your choose " + suit1)
                                        client.sendMessage(player2[0], 'select your choose >gunting or >batu or >kertas')
                                    else:
                                        sendMention(player1[0], "Choice until correct >gunting or >batu or >kertas\n@!", [player1[0]])
                                wait['suit1'] = False
                                wait['suit2'] = True
                            if text.lower() == "result suit":
                                client.sendMessage(msg.to, "kan hasilnya udah di kasih di pc")
                            if wait['suit2'] == True:
                                if text.lower().startswith(">"):
                                    if sender in player2:
                                        suit2 = text.lower().replace(">","")
                                        if suit2 == "kertas" or suit2 == "batu" or suit2 == "gunting":
                                            set2.append(suit2)
                                            client.sendMessage(sender, "your choose " + suit2)
                                        else:
                                            sendMention(player2[0], "Choice until correct >gunting or >batu or >kertas\n@!", [player2[0]])
                                        if set1[0] == "gunting" and set2[0] == "batu":
                                            sendMention(to, 'Player 2 win @!', [player2[0]])
                                            sendMention(player1[0], 'Player 2 win @!', [player2[0]])
                                            suit['score'][player2[0]]['sc']=suit['score'][player2[0]]['sc']+1
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            wait['suit'] = False
                                        if set1[0] == "gunting" and set2[0] == "kertas":
                                            sendMention(to, 'Player 1 win @!', [player1[0]])
                                            sendMention(player1[0], 'Player 1 win @!', [player1[0]])
                                            suit['score'][player1[0]]['sc']=suit['score'][player1[0]]['sc']+1
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            wait['suit'] = False
                                        if set1[0] == "gunting" and set2[0] == "gunting":
                                            client.sendMessage(to, 'Seri')
                                            client.sendMessage(player1[0], 'Seri')
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            wait['suit'] = False
                                        if set1[0] == "batu" and set2[0] == "batu":
                                            client.sendMessage(to, 'Seri')
                                            client.sendMessage(player[0], 'Seri')
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            #set1.remove(set1[0])
                                            #set2.remove(set2[0])
                                            wait['suit'] = False
                                        if set1[0] == "batu" and set2[0] == "kertas":
                                            sendMention(to, 'Player 2 win @!', [player2[0]])
                                            sendMention(player1[0], 'Player 2 win @!', [player2[0]])
                                            suit['score'][player2[0]]['sc']=suit['score'][player2[0]]['sc']+1
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            #set1.remove(set1[0])
                                            #set2.remove(set2[0])
                                            wait['suit'] = False
                                        if set1[0] == "batu" and set2[0] == "gunting":
                                            sendMention(to, 'Player 1 win @!', [player1[0]])
                                            sendMention(player1[0], 'Player 1 win @!', [player1[0]])
                                            suit['score'][player1[0]]['sc']=suit['score'][player1[0]]['sc']+1
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            #set1.remove(set1[0])
                                            #set2.remove(set2[0])
                                            wait['suit'] = False
                                        if set1[0] == "kertas" and set2[0] == "batu":
                                            sendMention(to, 'Player 1 win @!', [player1[0]])
                                            sendMention(player1[0], 'Player 1 win @!', [player1[0]])
                                            suit['score'][player1[0]]['sc']=suit['score'][player1[0]]['sc']+1
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            #set1.remove(set1[0])
                                            #set2.remove(set2[0])
                                            wait['suit'] = False
                                        if set1[0] == "kertas" and set2[0] == "kertas":
                                            client.sendMessage(to, 'Seri')
                                            client.sendMessage(player1[0], 'Seri')
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            #set1.remove(set1[0])
                                            #set2.remove(set2[0])
                                            wait['suit'] = False
                                        if set1[0] == "kertas" and set2[0] == "gunting":
                                            sendMention(to, 'Player 2 win @!', [player2[0]])
                                            sendMention(player1[0], 'Player 2 win @!', [player2[0]])
                                            suit['score'][player2[0]]['sc']=suit['score'][player2[0]]['sc']+1
                                            set1.clear()
                                            set2.clear()
                                            player1.clear()
                                            player2.clear()
                                            #set1.remove(set1[0])
                                            #set2.remove(set2[0])
                                            wait['suit'] = False
                                    wait['suit1'] = False
                                    wait['suit2'] = False

                        if text.lower() == 'view player quest':
                            no = 0
                            ls = 'List player\n'
                            for a in dts['player']:
                                no = no+1
                                name = client.getContact(a).displayName
                                ls += str(no)+'. '+name+'\n'
                            client.sendMessage(msg.to, ls)
                        if text.lower() == 'join quest':
                                if len(player) >= 20:
                                    client.sendMessage(msg.to, 'player full max 20')
                                else:
                                    wil = client.getContact(sender)
                                    name = client.getContact(sender).displayName
                                    if sender in dts['player']:
                                        sendMention(to, "Sudah Join @! ", [sender])
                                    else:
                                        dts['score'][sender]['sc']=0
                                        dts['player'].append(sender)
                                        client.sendMessage(msg.to, "Ketik {view player} untuk liat list yang main,Ketik #soal untuk mulai")

                        if text.lower() == 'myscore':
                            if sender in dts['score']:
                                client.sendMessage(msg.to,'Your score questions is {}'.format(str(dts['score'][sender]['sc'])))
                            else:
                                client.sendMessage(msg.to,'Your score questions is 0')
                        if text.lower() == "leaderboards quest":
                            try:
                                    if sender in dts['player']:
                                        no = 0
                                        ls = '[ LeaderBoards ]\nType game : questions\n'
                                        for a in dts['player']:
                                            no =no+1
                                            kintil = client.getContact(a).displayName
                                            score = str(dts['score'][a]['sc'])
                                            ls += str(no)+'. '+kintil+' : '+score+'\n'
                                        ls += '\n     [ Creator rizal ]'
                                        client.sendReplyMessage(msg_id, to, str(ls))
                                        wait["quest"] = False
                                    else:
                                        sendMention(to, 'ketik {join} first \n> @!', [sender])
                            except Exception as e:
                                client.sendMessage(msg.to, str(e))
                        if wait["quest"] == True:
                            try:
                                if cmd == '#nyerah':
                                    if sender in dts['player']:
                                        wait["quest"] = True
                                        client.sendMessage(msg.to,'Yah nyerah')
                                        wait["quest"] = False
                                    else:
                                        sendMention(to, 'ketik {join} first \n> @!', [sender])
                                if text.lower().startswith('>'):
                                    if wait["quest"] == True:
                                        if sender in dts['player']:
                                            if ' ' not in text.lower():
                                                this = text.lower().replace('>','')
                                                if dts[this] == dts['yes']:
                                                    if sender not in dts['score']:
                                                        dts['score'][sender]={'sc':1,'mid':sender}
                                                    else:
                                                        dts['score'][sender]['sc']+=1
                                                    client.sendMessage(msg.to,'Your answer is right')
                                                    wait["quest"] = False
                                                else:
                                                    client.sendMessage(msg.to,'Your answer is wrong')
                                                    wait["quest"] = False
                                            else:
                                                this = text.split(' ')[1]
                                                if this == dts['yes']:
                                                    if sender not in dts['score']:
                                                        dts['score'][sender]={'sc':1,'mid':sender}
                                                    else:
                                                        dts['score'][sender]['sc']+=1
                                                    client.sendMessage(msg.to,'Your answer is right')
                                                    wait["quest"] = False
                                                else:
                                                    client.sendMessage(msg.to,'Your answer is wrong')
                                                    wait["quest"] = False
                                        else:
                                            sendMention(to, 'Ketik {Join} first\n> @!', [sender])
                            except Exception as e:
                                client.sendMessage(msg.to, str(e))
                       
        if op.type == 26 or op.type == 25:
            try:
                print ("[ 26 ] SEND MESSAGE")
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                stickername = str(text)
                setKey = settings["keyCommand"].title()
                if settings["setKey"] == False:
                    setKey = ''                      
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != client.profile.mid:
                            to = sender
                        else:
                            to = receiver                           
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if msg.contentType == 0:
                        if text is None:
                            return
                        else:
                            cmd = command(text)
                            if receiver in temp_flood:
                               if temp_flood[receiver]["expire"] == True:
                                  if cmd == "open":
                                       temp_flood[receiver]["expire"] = False
                                       temp_flood[receiver]["time"] = time.time()
                                       client.sendMessage(to,"Bot Actived")
                                  return
                               elif time.time() - temp_flood[receiver]["time"] <= 5:
                                   temp_flood[receiver]["flood"] += 1
                                   if temp_flood[receiver]["flood"] >= 20:
                                       temp_flood[receiver]["flood"] = 0
                                       temp_flood[receiver]["expire"] = True
                                       ret_ = "I will be off for 30 seconds, type open to re-enable"
                                       userid = "https://line.me/ti/p/~" + client.profile.userid
                                       client.sendMessage(to, "Flood Detect ! Bot will silent 30 seconds! Type Open to unmute bot in this room!")
                               else:
                                   temp_flood[receiver]["flood"] = 0
                               temp_flood[receiver]["time"] = time.time()
                            else:
                               temp_flood[receiver] = {
    	                           "time": time.time(),
    	                           "flood": 0,
    	                           "expire": False
                               }
                            if cmd == "#self on":
                            	if to not in offbot:
                            		client.sendMessage(to, "Bot On, Untuk NonAktifkan Bot Ketik #Self off")
                            		offbot.append(to)
                            		print (to)
                            	else:
                            		client.sendMessage(to, "Bot On, Untuk NonAktifkan Bot Ketik #Self off")
                            elif cmd == "#self off":
                            	if to in offbot:
                            		offbot.remove(to)
                            		client.sendMessage(to, "Bot Off, Untuk Aktifkan Bot Ketik #Self on")
                            		print (to)
                            	else:
                            		client.sendMessage(to, "Bot Off, Untuk Aktifkan Bot Ketik #Self on")
                            if to in offbot:
                            	return    
                             
                            elif cmd == "help":
                              if msg._from in Owner:
                              #  helpMessage = helpmessage()
                               # client.sendReplyMessage(msg.id, to, str(helpMessage))                    
                                imageHelp(to)
                             
                            elif cmd == "settings":
                              if msg._from in Owner:
                                helpSettings = helpsettings()         
                                flexHelp(to, helpSettings)                       
                            #    client.sendReplyMessage(msg.id, to, str(helpSettings))
                                
                            elif cmd == "media":
                              if msg._from in Owner:
                              #  helpMedia = helpmedia()                  
                                helpMedia1 = helpmedia1()             
                             #   flexHelp(to, "Tes", )
                                flexHelp(to, helpMedia1)
                                
                            elif cmd == "token":
                                helpToken = helptoken()
                                flexHelp(to, helpToken)
                               # contact = client.getContact(msg._from)
                                #client.sendReplyMessage(msg.id, to, str(helpToken), {'AGENT_LINK': 'http://line.me/ti/p/dkjb7i9krs','AGENT_ICON': "http://dl.profile.line-cdn.net/" + contact.pictureStatus,'AGENT_NAME': "Special for u"})
                                
                            elif cmd == "special":
                                if msg._from in Owner:                                    
                                    helpSpecial1 = helpspecial1()                                
                                    flexHelp(to, helpSpecial1)
                                    
                            elif cmd == "pagi":
                              if msg._from in Owner:
                                 imageHelp1(to)
                                 
                            elif cmd == "token1":
                                imageHelp2(to)
                                    
                            elif cmd == "sp":
                              if msg._from in Owner:
                               start = time.time()
                               client.sendReplyMessage(msg.id, to, "「 SelfBot Speed 」")
                               elapsed_time = time.time() - start
                               client.sendReplyMessage(msg.id, to, "『 {}Detik 』".format(str(elapsed_time)))
                               print ('[Notif] Speed success')
                               
                            elif cmd == "speed":
                                start = time.time()                              
                                elapsed_time = time.time() - start
                                took = time.time() - start
                                client.sendReplyMessage(msg.id, to,"「 Speed 」\n - Took : %.3fms\n - Taken: %.10f" % (took,elapsed_time))
                                                            
                            elif cmd == "runtime":
                              if msg._from in Owner:
                                timeNow = time.time()
                                runtime = timeNow - botStart
                                runtime = format_timespan(runtime)
                                contact = client.getContact(msg._from)
                                flexText(to, "Bot sudah berjalan selama {}".format(str(runtime)), "#0000FF")
                                
                            elif cmd.startswith("flex "):
                                if msg._from in Owner:
                                  bis = text.split(" ")
                                  bis = text.replace(bis[0]+" "," ")
                                  bis = bis.split('|')
                                  txt = str(bis[0])
                                  flexText(to, txt, "#0000FF")
                                  
                            elif cmd.startswith("footer "):
                                if msg._from in Owner:
                                  bis = text.split(" ")
                                  bis = text.replace(bis[0]+" "," ")
                                  bis = bis.split('|')
                                  txt = str(bis[0])
                                  data = {"messages":[{"type":"text","text": txt,"sentBy":{"label":" ➴ͥ ͣ ͫͫ͢૨ᴋɪɴɢs•🔰™̶̅✫","iconUrl":'http://dl.profile.line-cdn.net/{}'.format(client.getContact(msg._from).pictureStatus),"linkUrl":"https://line.me/ti/p/~mr.sider"}}]}
                                  sendTemplate(to, data)
                                  
                            elif cmd == "price":
                                 helpPrice = helpprice()
                                 flexHelp1(to, helpPrice)
                                 
                            elif cmd == "restart":
                                if msg._from in Owner:
                                 client.sendReplyMessage(msg.id, to, "Berhasil merestart Bot")
                                 restartBot()
                                 
                            elif cmd == "cvp":
                            	if msg._from in Owner:
                                    settings['changeProfileVideo']['status'] = True
                                    settings['changeProfileVideo']['stage'] = 1
                                    client.sendMessage(to, "Send Video !!")                                                            
                                                       
                            if cmd == "creator":
                               if msg._from in Owner:
                                  ticket = "http://line.me/ti/p/"+client.getUserTicket().id
                                  client.sendMessage(to, "My Creator ", {'QUICK_REPLY': '{"items": [{"type": "action","useTintColor": False,"imageUrl": "http://dl.profile.line-cdn.net/0hqpw3casrLl9KSgPLIGVRCHYPIDI9ZCgXMnk2am0fIDozLWpZc3g1PmwYJ2k0f2hcJio1bDsYdj1g","action": {"type": "uri","label": "Like","uri": "https://line.me/ti/p/~mr.sider "}},{"type": "action","useTintColor": False,"imageUrl": "http://dl.profile.line-cdn.net/0hqpw3casrLl9KSgPLIGVRCHYPIDI9ZCgXMnk2am0fIDozLWpZc3g1PmwYJ2k0f2hcJio1bDsYdj1g","action": {"type": "uri","label": "Love","uri":"https://line.me/ti/p/~mr.sider "}}]}'}, 0)
  
                          #  elif text.lower() == '@byebot':
                             #   if msg.toType == 2:
                                #   ge = ("u0669082c18c5e369586fcb3cc4723407")
                                #   ginfo = client.getGroup(to)
                                #   try:
                                  #     client.sendReplyMessage(msg.id, to,"Terimakasih sudah menginvite saya")
                                  #     time.sleep(1)
                                  #     client.leaveGroup(to)
                                  # except:
                                     #  pass                                                                                                                  

                          #  elif cmd == "byebot":
                               # client.sendMessage(to, "Asw lo mau kick w")
                              #  client.sendMessage(to, "Nich w balikin")
                             #   client.sendMessage(to, "Wkwkwkwkkw")
                               # client.kickoutFromGroup(msg.to,[sender])
                               # client.inviteIntoGroup(msg.to,[sender])
                               
                            elif cmd == "byeme":
                               if wait["selfbot"] == True:
                                 if msg._from in Owner:
                                    G = client.getGroup(msg.to)
                                    client.sendReplyMessage(msg.id, to, "Bye bye "+str(G.name))
                                    client.leaveGroup(msg.to)
                           
                            elif cmd == "logout":
                                if msg._from in Owner:
                                    client.sendReplyMessage(msg.id, to, "Berhasil Mematikan Bot")
                                    sys.exit("[INFO] BOT SHUTDOWN")           
                                  
                            elif cmd.startswith("clearchat"):
                            	if msg._from in Owner:
                                    client.removeAllMessages(op.param2)
                                    client.sendMessage(to, "Remove chat history")

                            elif cmd.startswith("gn "):
                                if msg._from in Owner:
                                  if msg.toType == 2:
                                      X = client.getGroup(to)
                                      sep = msg.text.split(" ")
                                      X.name = msg.text.replace(sep[0] + " ","")
                                      client.updateGroup(X)
                                                              
                            elif cmd.lower() == 'announce':
                                if msg._from in Owner:
                                    try:
                                        gett = client.getChatRoomAnnouncements(msg.to)
                                        for a in gett:
                                            aa = client.getContact(a.creatorMid).displayName
                                            bb = a.contents
                                            cc = bb.link
                                            textt = bb.text
                                            client.sendReplyMessage(msg.id, to, 'Pemberitahuan Grup\n\nLink: ' + str(cc) + '\nPenulis: ' + str(aa) + '\nTeksnya: ' + str(textt))
                                            break
                                    except Exception as e:
                                        client.sendReplyMessage(msg.id, to, "Pemberitahuan Grup Tidak Ditemukan")                                
                                        
                            elif text.lower() == "pagi1":
                                contact = client.getContact(msg._from)
                                data = {
								    "messages": [
									       {
											    "type": "template",
											    "altText": "This Is My Steal",
											    "template": {
												    "type": "image_carousel",
												    "columns": [
													    {
														 "imageUrl": "https://media.giphy.com/media/l0NwSvw3kQWZuUW8E/giphy.gif",
														 "action": {
															 "type": "uri",
															 "uri": "http://line.me/ti/p/~mr.sider"
														    }
													    }
												    ]
											    }
										    }
								    ]
							    }
                                sendTemplate(to, data) 

                            elif text.lower() == 'about':
                              if msg._from in Owner:
                                try:
                                    arr = []
                                    today = datetime.today()
                                    thn = 2019
                                    bln = 1    #isi bulannya yg sewa
                                    hr = 9    #isi tanggalnya yg sewa
                                    future = datetime(thn, bln, hr)
                                    days = (str(future - today))
                                    comma = days.find(",")
                                    days = days[:comma]
                                    owner = "u4033ea77038ab1a6ec89c42fe317f7ab"
                                    friend = client.getAllContactIds()
                                    group = client.getGroupIdsJoined()
                                    blockedlist = client.getBlockedContactIds()
                                    timeNow = time.time()
                                    runtime = timeNow - botStart
                                    runtime = format_timespan(runtime)
                                    tz = pytz.timezone("Asia/Jakarta")
                                    timeNow = datetime.now(tz=tz)                                    
                                    ret_ = "╭──[ Type SelfBot Premium ]"
                                    ret_ += "\n├≽ Creator : @!"
                                    ret_ += "\n├≽ User Id : http://line.me/ti/p/"+client.getUserTicket().id
                                    ret_ += "\n├≽ Friend : {}".format(str(len(friend)))
                                    ret_ += "\n├≽ Group : {}".format(str(len(group)))
                                    ret_ += "\n├≽ Blocked : {}".format(str(len(blockedlist)))    
                                    ret_ += "\n├≽ Expired : {}-{}-{}".format(str(hr), str(bln), str(thn))
                                    ret_ += "\n├≽ In days : {} again".format(days)                                
                                    ret_ += "\n├≽ Version : Sb v1.3"
                                    ret_ += "\n├≽ Runtime : {}".format(str(runtime))
                                    ret_ += "\n├──[ About Time ]"
                                    ret_ += "\n├≽ Tanggal : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                    ret_ += "\n├≽ Jam : " + datetime.strftime(timeNow,'%H:%M:%S') + " WIB"
                                    ret_ += "\n├──[ Special Thanks to ]"
                                    ret_ += "\n├≽ Tuhan Yang Maha Esa"
                                    ret_ += "\n╰───[ Finish ]"
                                    sendMention(to, ret_, [owner])
                                except Exception as e:
                                    client.sendMessage(msg.to, str(e))         
                                    
                            if cmd == "hay":
                              if msg._from in Owner:
                                client.sendMessage(to, "Love or Like ?", {'QUICK_REPLY': '{"items": [{"type": "action","useTintColor": False,"imageUrl": "https://banner2.kisspng.com/20180319/rxw/kisspng-facebook-like-button-facebook-like-button-computer-facebook-new-like-symbol-5ab036a9b8fac7.0338659015214977697577.jpg","action": {"type": "message","label": "Like","text": "Maaf saya homo"}},{"type": "action","useTintColor": False,"imageUrl": "https://png.pngtree.com/element_our/png/20180809/love-reaction-facebook-png_58127.jpg","action": {"type": "message","label": "Love","text": "Maaf saya lesbi"}}]}'}, 0)

                            elif cmd == "rejectall" or text.lower() == "rejectspam":
                              if msg._from in Owner:
                                ginvited = client.getGroupIdsInvited()
                                if ginvited != [] and ginvited != None:
                                    for gid in ginvited:
                                        client.rejectGroupInvitation(gid)
                                    client.sendReplyMessage(msg.id, to, "Berhasil tolak sebanyak {} undangan grup".format(str(len(ginvited))))
                                else:
                                    client.sendReplyMessage(msg.id, to, "Undanga sepam abal abal telah di hapus tam")                                              

                            elif cmd.startswith("flexgbc "):
                            	if msg._from in Owner:
                                    sep = text.split(" ")
                                    txt = text.replace(sep[0] + " ","")                                                                                                            
                                    groups = client.groups
                                    contact = client.getContact(msg._from)
                                    for group in groups:
                                       # client.sendMessage(group, "[ Broadcast ]\n{}".format(str(txt)))
                                        bctemplate(group, txt)
                                       # flexText(group, "[ Broadcast ]\n{}".format(str(txt)), "#0000FF")
                                    client.sendMessage(to, "Berhasil broadcast ke {} group".format(str(len(groups))))
                                    
                            elif cmd.startswith("footergbc "):
                            	if msg._from in Owner:
                                    sep = text.split(" ")
                                    txt = text.replace(sep[0] + " ","")                                                                                                            
                                    groups = client.groups
                                    contact = client.getContact(msg._from)
                                    for group in groups:
                                   #    client.sendMessage(group, "[ Broadcast ]\n{}".format(str(txt)))
                                       data = {"messages":[{"type":"text","text": txt,"sentBy":{"label":" ➴ͥ ͣ ͫͫ͢૨ᴋɪɴɢs•🔰™̶̅✫","iconUrl":'http://dl.profile.line-cdn.net/{}'.format(client.getContact(msg._from).pictureStatus),"linkUrl":"https://line.me/ti/p/~mr.sider"}}]}
                                       sendTemplate(group, data)
                                       # flexText(group, "[ Broadcast ]\n{}".format(str(txt)), "#0000FF")
                              #      client.sendMessage(to, "Berhasil broadcast ke {} group".format(str(len(groups))))
                              
                            elif cmd.startswith("gbc: "):
                                if msg._from in Owner:
                                    sep = text.split(" ")
                                    txt = text.replace(sep[0] + " ","")
                                    groups = client.getGroupIdsJoined()
                                    for group in groups:
                                       client.sendMessage(group, "[ Broadcast ]\n{}".format(str(txt)))
                                    client.sendMessage(to, "Berhasil broadcast ke {} group".format(str(len(groups))))

                            elif cmd.startswith("exec"):
                              if msg._from in Owner:
                               if sender in ["u4033ea77038ab1a6ec89c42fe317f7ab"]:
                            	    try:
                            		    sep = text.split(" ")
                            		    search = text.replace(sep[0] + " ","")
                            		    exec(search)
                            	    except Exception as error:
                            		    client.sendMessage(to, str(error))
                            
                         #   elif cmd == "hmm":
                              #  client.sendReplyMessage(msg.id, to, "Waduh Anda Batuk Segeralah Minum Baygon Penyakit Ilang Nyawa Melayang")
                         #   elif cmd == "hi":
                             #   client.sendReplyMessage(msg.id, to, "Hi too")
                           # elif cmd == "joker":
                            #    client.sendReplyMessage(msg.id, to, "Moshimoshi (もしもし)")
                            #elif cmd == "sayang":
                            #    client.sendReplyMessage(msg.id, to, "Iya sayang,ada apa ?")                            
                            #elif cmd == "welcome":
                               # client.sendReplyMessage(msg.id, to, "Selamat datang di Group")
                             #   client.sendReplyMessage(msg.id, to, "Have fun darling!")
# Pembatas Script #
                            elif cmd == "autoadd on":
                                if msg._from in Owner:
                                 settings["autoAdd"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan auto add")
                                
                            elif cmd == "autoadd off":
                                if msg._from in Owner:
                                 settings["autoAdd"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan auto add")
                                
                            elif cmd == "autojoin on":
                                if msg._from in Owner:
                                 settings["autoJoin"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan auto join")
                                
                            elif cmd == "autojoin off":
                                if msg._from in Owner:
                                 settings["autoJoin"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan auto join")
                                 
                            elif cmd == "autoleave on":
                                if msg._from in Owner:
                                 settings["autoLeave"] = True,
                                 client.sendMessage(to, "Berhasil mengaktifkan auto leave")
                                
                            elif cmd == "autoleave off":
                                if msg._from in Owner:
                                 settings["autoLeave"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan auto leave")
                                
                            elif cmd == "autorespon on":
                                if msg._from in Owner:
                                 settings["autoRespon"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan auto respon")
                                
                            elif cmd == "autorespon off":
                                if msg._from in Owner:
                                 settings["autoRespon"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan auto respon")
                                
                            elif cmd == "autoread on":
                                if msg._from in Owner:
                                 settings["autoRead"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan auto read")
                                
                            elif cmd == "autoread off":
                                if msg._from in Owner:
                                 settings["autoRead"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan auto read")
                                 
                            elif cmd == "autojointicket on":
                                if msg._from in Owner:
                                 settings["autoJoinTicket"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan auto join by ticket")
                                
                            elif cmd == "autojointicket off":
                                if msg._from in Owner:                            	
                                 settings["autoJoin"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan auto join by ticket")
                                 
                            elif cmd == "checkcontact on":
                                if msg._from in Owner:
                                 settings["checkContact"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan check details contact")
                                
                            elif cmd == "checkcontact off":
                                if msg._from in Owner:
                                 settings["checkContact"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan check details contact")
                                
                            elif cmd == "checkpost on":
                                if msg._from in Owner:
                                 settings["checkPost"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan check details post")
                                
                            elif cmd == "checkpost off":
                                if msg._from in Owner:
                                 settings["checkPost"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan check details post")
                                
                            elif cmd == "checksticker on":
                                if msg._from in Owner:
                                 settings["checkSticker"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan check details sticker")
                                
                            elif cmd == "checksticker off":
                                if msg._from in Owner:
                                 settings["checkSticker"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan check details sticker")
                                
                            elif cmd == "unsendchat on":
                                if msg._from in Owner:
                                 settings["unsendMessage"] = True
                                 client.sendMessage(to, "Berhasil mengaktifkan unsend message")
                                
                            elif cmd == "unsendchat off":
                                if msg._from in Owner:
                                 settings["unsendMessage"] = False
                                 client.sendMessage(to, "Berhasil menonaktifkan unsend message")
                               
                            elif cmd == "welcome on":
                                if msg._from in Owner:
                                 settings["welcomeMessage"] = True
                                 client.sendMessage(to, "Berhasil Mengaktifkan Sambutan")
  
                            elif cmd == "welcome off":
                                if msg._from in Owner:
                                 settings["welcomeMessage"] = False
                                 client.sendMessage(to, "Berhasil Menonatifkan Sambutan")
 
                            elif msg.text in ["Simi on"]:
                                if msg._from in Owner:
                                 simi2["simi-simi"][msg.to] = True
                                 client.sendMessage(to, "Simi-Simi Sudah Aktif")

                            elif msg.text in ["Simi off"]:
                                if msg._from in Owner:
                                 simi2["simi-simi"][msg.to] = False
                                 client.sendMessage(to, "Simi-Simi Dinonaktifkan")      
                             
                            elif cmd == "sider off":
                              if msg._from in Owner:
                                if msg.to in cctv['point']:
                                    cctv['cyduk'][msg.to]=False
                                    wait["Sider"] = False
                                    client.sendMessage(msg.to, "Cek Sider Off")
                                else:
                                    client.sendMessage(msg.to, "Heh Belom Di Set")
                                    
                            elif cmd =="sider on":
                              if msg._from in Owner:
                                try:
                                    del cctv['point'][msg.to]
                                    del cctv['sidermem'][msg.to]
                                    del cctv['cyduk'][msg.to]
                                except:
                                           pass
                                           cctv['point'][msg.to] = msg.id
                                           cctv['sidermem'][msg.to] = ""
                                           cctv['cyduk'][msg.to]=True
                                           wait["Sider"] = True
                                           client.sendMessage(msg.to,"Siap On Cek Sider")    
                               
   
                            elif cmd == "status":
                              if msg._from in Owner:
                                    ret_ = "╭───「 Status 」────"
                                    if settings["autoAdd"] == True: ret_ += "\n│Auto Add「 ON 」"
                                    else: ret_ += "\n│Auto Add「 OFF 」"
                                    if settings["autoJoin"] == True: ret_ += "\n│Auto Join「 ON 」"
                                    else: ret_ += "\n│Auto Join「 OFF 」"
                                    if settings["autoLeave"] == True: ret_ += "\n│Auto Leave Room「 ON 」"
                                    else: ret_ += "\n│Auto Leave Room「 OFF 」"
                                    if settings["autoJoinTicket"] == True: ret_ += "\n│Auto Join Ticket「 ON 」"
                                    else: ret_ += "\n│Auto Join Ticket「 OFF 」"
                                    if settings["autoRead"] == True: ret_ += "\n│Auto Read「 ON 」"
                                    else: ret_ += "\n│Auto Read「 OFF 」"
                                    if settings["autoRespon"] == True: ret_ += "\n│Detect Mention「 ON 」"
                                    else: ret_ += "\n│Detect Mention「 OFF 」"
                                    if settings["checkContact"] == True: ret_ += "\n│Check Contact「 ON 」"
                                    else: ret_ += "\n│Check Contact「 OFF 」"
                                    if settings["checkPost"] == True: ret_ += "\n│Check Post「 ON 」"
                                    else: ret_ += "\n│Check Post「 OFF 」"
                                    if settings["checkSticker"] == True: ret_ += "\n│Check Sticker「 ON 」"
                                    else: ret_ += "\n│Check Sticker「 OFF 」"
                                    if settings["setKey"] == True: ret_ += "\n│Set Key「 ON 」"
                                    else: ret_ += "\n│Set Key「 OFF 」"
                                    if settings["unsendMessage"] == True: ret_ += "\n│Unsend Message「 ON 」"
                                    else: ret_ += "\n│Unsend Message「 OFF 」"
                                    ret_ += "\n╰「[JTB]ᎫϴᏦᎬᎡ ͲᎬᎪᎷ ᏴϴͲ」"
                                    data = {"messages":[{"type":"text","text": ret_,"sentBy":{"label":" ➴ͥ ͣ ͫͫ͢૨ᴋɪɴɢs•🔰™̶̅✫","iconUrl":'http://dl.profile.line-cdn.net/{}'.format(client.getContact(msg._from).pictureStatus),"linkUrl":"https://line.me/ti/p/~mr.sider"}}]}
                                    sendTemplate(to, data)
                                 #   client.sendReplyMessage(msg.id, to, ret_)
# Pembatas Script #
#============================================
#============================================
                            elif stickername == cmd:
                              with open('sticker.json','r') as fp:
                                stickers = json.load(fp)
                              if cmd in stickers:
                                sid = stickers[text.lower()]["STKID"]
                                spkg = stickers[text.lower()]["STKPKGID"]
                                if "STKOPT" in stickers[text.lower()]:
                                  url = "https://stickershop.line-scdn.net/stickershop/v1/sticker/"+sid+"/IOS/sticker_animation@2x.png"
                                else:
                                  url = "https://stickershop.line-scdn.net/stickershop/v1/sticker/"+sid+"/ANDROID/sticker.png"
                                print(url)
                                templatesendSticker(to, url, "line://shop/detail/"+spkg)
#============================
                            elif cmd.startswith("addsticker "):
                              sep = text.split(" ")
                              name = text.replace(sep[0] + " ","")
                              name = name.lower()
                              with open('sticker.json','r') as fp:
                                stickers = json.load(fp)
                              if name not in stickers:
                                settings["addSticker"]["status"] = True
                                settings["addSticker"]["name"] = str(name.lower())
                                stickers[str(name.lower())] = {}
                                f = codecs.open('sticker.json','w','utf-8')
                                json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                client.sendReplyMessage(msg.id,to, "Send your stickers!")
                              else:
                                client.sendReplyMessage(msg.id,to, "Stickers name already in List!")
                                
                            elif cmd.startswith("dellsticker "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                name = text.replace(sep[0] + " ","")
                                name = name.lower()
                                if name in stickers:
                                    del stickers[str(name.lower())]
                                    f = codecs.open("sticker.json","w","utf-8")
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    client.sendText(msg.to, "Berhasil menghapus sticker {}".format( str(name.lower())))
                                else:
                                    client.sendText(msg.to, "Sticker itu tidak ada dalam list") 
                                 
                            elif cmd == "stickerlist":
                              with open('sticker.json','r') as fp:
                                stickers = json.load(fp)
                              ret_ = "[ Sticker List ]"
                              for sticker in stickers:
                                ret_ += "\n*  " + sticker.title()
                              ret_ += "\n[ Total {} Stickers ]".format(str(len(stickers)))
                              client.sendReplyMessage(msg.id,to, ret_)
#============================
#==============================================================================#
                            elif cmd == "crash":
                            	if msg._from in Owner:
                                 client.sendContact(to, "u6347d96f19332503ee90b48d630ec27e',")                                 
                                                                                                                                                           
                            elif cmd == "mee":
                              if msg._from in Owner:
                                sendMention(to, "「 ᴍʏ ɴᴀᴍᴇ 」\n @! ", [sender])
                                contact = client.getContact(sender)
                                nomer = contact.statusMessage
                                nama = contact.displayName
                                client.sendContactHP(to, text, nomer, nama)
                               # musik(to)
                                image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus       
                                client.sendReplyMessage(msg.id, to, contact.displayName, contentMetadata={'countryCode': 'ID', 'i-installUrl': 'line://ti/p/~mr.sider', 'a-packageName': 'com.spotify.music', 'linkUri': 'line://ti/p/~mr.sider', 'subText': contact.statusMessage, 'a-installUrl': 'line://ti/p/~mr.sider', 'type': 'mt', 'previewUrl': image, 'a-linkUri': 'line://ti/p/~mr.sider', 'Text': contact.displayName,'id': 'mt000000000a6b79f9', 'i-linkUri': 'line://ti/p/~mr.sider'}, contentType=19)
                                
                            elif cmd == "test":
                                ret = "Helper Login :\n"
                                ret += "  • Login sb\n"
                                ret += "  • Logout sb\n"
                                ret += "  • Restart sb\n"
                                ret += "  • Help login"
                                hello = "{}".format(str(ret))
                                data = {
                                    "type": "text",
                                    "text": "{}".format(str(ret)),
                                    "sentBy": {
                                        "label": "Alfian Bisma",
                                        "iconUrl": "https://obs.line-scdn.net/{}".format(client.getContact(clientMID).pictureStatus),
                                        "linkUrl": "line://nv/profilePopup/mid=u4033ea77038ab1a6ec89c42fe317f7ab"
                                    }
                                }
                                sendTemplate(to, data)
                                
                            elif cmd == "hy":
                                helpToken = helptoken()
                                buttonHelp(to, helpToken)
                                                                                                                                                       
                            elif cmd == "me":
                                contact = client.getContact(sender)
                                data = {
                                    "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "Profile",
                                            "contents": {
                                                "type": "bubble",
                                                "styles": {
                                                        "header": {
                                                            "backgroundColor": "#1C1C1C",
                                                        }, 
                                                        "body": {
                                                            "backgroundColor": "#1C1C1C",
                                                        }, 
                                                        "footer": {
                                                            "backgroundColor": "#1C1C1C",
                                                            "separator": True
                                                        }
                                                    },
                                                "header": {
                                                    "type": "box",
                                                    "layout": "horizontal",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "text": "{}".format(contact.displayName),
                                                            "weight": "bold",
                                                            "color": "#FF4500",
                                                            "size": "sm"
                                                        }
                                                    ]
                                                },
                                                "hero": {
                                                    "type": "image",
                                                    "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus),
                                                    "size": "full",
                                                    "aspectRatio": "1:1",
                                                    "aspectMode": "cover",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://ti/p/~mr.sider"
                                                    }
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Name",
                                                                            "color": "#00FFFF",
                                                                            "size": "sm",
                                                                            "flex": 1
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(contact.displayName),
                                                                            "color": "#FF4500",
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                },
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "text": "Bio",
                                                                            "color": "#00FFFF",
                                                                            "size": "sm",
                                                                            "flex": 1
                                                                        },
                                                                        {
                                                                            "type": "text",
                                                                            "text": "{}".format(contact.statusMessage),
                                                                            "color": "#FF4500",
                                                                            "wrap": True,
                                                                            "size": "sm",
                                                                            "flex": 5
                                                                        }
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "md",
                                                    "contents": [
                                                        {
                                                            "type": "button",
                                                            "height": "sm",
                                                            "style": "primary",
                                                            "action": {
                                                                "type": "uri",
                                                                "label": "CONTACT PERSON",
                                                                "uri": "line://nv/profilePopup/mid={}".format(msg._from)
                                                            }                                                   
                                                        },
                                                        {
                                                            "type": "spacer",
                                                            "size": "sm",
                                                        }
                                                    ],
                                                    "flex": 0
                                                }
                                            }
                                        }
                                    ]
                                }
                                sendTemplate(to, data)
                                
                            elif cmd == "game":
                              if wait["selfbot"] == True:
                                if msg._from in Owner:
                                   contact = client.getContact(msg._from)
                                   to = msg.to
                                   data = {
								       "messages": [
									       {
										       "type": "template",
										       "altText": "Game",
										       "template": {
											       "type": "carousel",
											       "actions": [],
											       "columns": [
												       {
													       "thumbnailImageUrl": "https://4.bp.blogspot.com/--v3eJySaEAc/WJ3h-xv71cI/AAAAAAAAAS4/MpCkvEUtcUQOb2Whl1JE9T6hoMHLhYFzQCLcB/s1600/road-rash.gif",
													       "title": "HIGHWAY",
													       "text": "Hindari Mobil Dan Berkendara Sebaik Mungkin",
													       "actions": [
														       {
															       "type": "uri",
															       "label": " PLAY ",
															       "uri": "line://app/1623679774-j4rZkZ51"
														       },
														       {
															       "type": "uri",
															       "label": "UnitedTeamBot",
															       "uri": "line://nv/profilePopup/mid=u4033ea77038ab1a6ec89c42fe317f7ab"
}
													       ]
												       }
											       ]
										       }
									       }
								       ]
							       }
                                   sendTemplate(to, data)
                                
                            elif cmd == "media":
                              if wait["selfbot"] == True:
                                if msg._from in Owner:
                                   contact = client.getContact(msg._from)
                                   to = msg.to
                                   data = {
								       "messages": [
									       {
										       "type": "template",
										       "altText": "Alfian Media",
										       "template": {
											       "type": "carousel",
											       "actions": [],
											       "columns": [
												       {
													       "thumbnailImageUrl": "https://media.giphy.com/media/10i63vOstd7sYg/giphy.gif",
													       "title": "✍❂྄ིᤢ⃟ᴜɴɪᴛᴇᴅ☠ ℬ⃢oⷨtͭ ⃟❂",
												           "text": "♻️ Lisquran",
												           "actions": [
														       {
															       "type": "uri",
															       "label": "Profile",
															       "uri": "line://nv/profile"
														       },
														       {
															       "type": "uri",
															       "label": "Creator",
															       "uri": "http://line.me/ti/p/~mr.sider"
														       }
													       ]
												       },
												       {
													       "thumbnailImageUrl": "https://media.giphy.com/media/JIzwj6ApQT6mI/giphy.gif",
													       "title": "✍❂྄ིᤢ⃟ᴜɴɪᴛᴇᴅ☠ ℬ⃢oⷨtͭ ⃟❂",
													       "text": "♻️ Kode Cctv",
													       "actions": [
														       {
															       "type": "uri",
															       "label": "Profile",
															       "uri": "line://nv/profile"
														       },
														       {
															       "type": "uri",
															       "label": "Creator",
															       "uri": "http://line.me/ti/p/~mr.sider"
}
													       ]
												       }
											       ]
										       }
									       }
								       ]
							       }
                                   sendTemplate(to, data)
                                   
                            elif cmd == "token":
                              if wait["selfbot"] == True:
                                if msg._from in Owner:
                                   contact = client.getContact(msg._from)
                                   to = msg.to
                                   data = {
								       "messages": [
									       {
										       "type": "template",
										       "altText": "Alfian Media",
										       "template": {
											       "type": "carousel",
											       "actions": [],
											       "columns": [
												       {
													       "thumbnailImageUrl": "https://media.giphy.com/media/10i63vOstd7sYg/giphy.gif",
													       "title": "CHROME",
												           "text": "♻️ ListToken",
												           "actions": [
														       {
															       "type": "uri",
															       "label": "Token%20Chrome",
															       "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Token%20chrome"
														       },
														       {
															       "type": "uri",
															       "label": "Token%20Done",
															       "uri": "line://app/1602687308-GXq4Vvk9?type=text&text=Token%20done"
														       }
													       ]
												       },
												       {
													       "thumbnailImageUrl": "https://media.giphy.com/media/JIzwj6ApQT6mI/giphy.gif",
													       "title": "",
													       "text": "♻️ Kode Cctv",
													       "actions": [
														       {
															       "type": "uri",
															       "label": "Profile",
															       "uri": "line://nv/profile"
														       },
														       {
															       "type": "uri",
															       "label": "Creator",
															       "uri": "http://line.me/ti/p/~mr.sider"
}
													       ]
												       }
											       ]
										       }
									       }
								       ]
							       }
                                   sendTemplate(to, data)
                                   
                            elif cmd == "#game":
                                ret = "╭─「Help Special」\n"
                                ret += "│#soal\n"
                                ret += "│Game suit\n"
                                ret += "│Join quest\n"
                                ret += "│View player quest\n"
                                ret += "│View player suit\n"
                                ret += "│Myscore\n"
                                ret += "│#start\n"
                                ret += "╰「[JTB]ᎫϴᏦᎬᎡ ͲᎬᎪᎷ ᏴϴͲ」"
                                data = {"messages":[{"type":"text","text": ret,"sentBy":{"label":" ➴ͥ ͣ ͫͫ͢૨ᴋɪɴɢs•🔰™̶̅✫","iconUrl":'http://dl.profile.line-cdn.net/{}'.format(client.getContact(msg._from).pictureStatus),"linkUrl":"https://line.me/ti/p/~mr.sider"}}]}
                                sendTemplate(to, data)
                                
                            elif cmd == "freearea":
                                contact = client.getContact(sender)
                                data = {
                                    "messages": [
                                        {
                                            "type": "flex",
                                            "altText": "Profile",
                                            "contents": 
                                                {
                                                "type": "bubble",
                                                "styles": {
                                                        "header": {
                                                            "backgroundColor": "#1C1C1C",
                                                        }, 
                                                        "body": {
                                                            "backgroundColor": "#1C1C1C",
                                                        }, 
                                                        "footer": {
                                                            "backgroundColor": "#1C1C1C",
                                                            "separator": True
                                                        }
                                                    },
                                                "header": {
                                                    "type": "box",
                                                    "layout": "baseline",
                                                    "contents": [
                                                        {
                                                            "type": "text",
                                                            "align": "center",
                                                            "text": "FREE AREA",
                                                            "weight": "bold",
                                                            "color": "#7FFFD4",
                                                            "size": "xl", 
                                "action" : {
  "type" : "uri", "uri" : "https://line.me/ti/p/~mr.sider"} 
                                                        }
                                                    ]
                                                },
                                                "body": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "contents": [
                                                        {
                                                            "type": "box",
                                                            "layout": "vertical",
                                                            "margin": "lg",
                                                            "spacing": "sm",
                                                            "contents": [
                                                                {
                                                                    "type": "box",
                                                                    "layout": "baseline",
                                                                    "spacing": "sm",
                                                                    "contents": [
                                                                        {
                                                                            "type": "text",
                                                                            "align": "center",
                                                                            "text": "FREE SB",
                                                                            "weight": "bold",
                                                                            "color": "#F0F8FF",
                                                                            "size": "xl"
                                                                        },
                                                                    ]
                                                                }
                                                            ]
                                                        }
                                                    ]
                                                },
                                                "footer": {
                                                    "type": "box",
                                                    "layout": "vertical",
                                                    "spacing": "sm",
                                                    "contents": [
                                                        {
                                                            "type": "button",
                                                            "style": "link",
                                                            "height": "sm",
                                                            "action": {
                                                                "type": "uri",
                                                                "label": "Free SB",
                                                                "uri": "http://line.me/ti/p/~mr.sider"
                                                            }                                                   
                                                        },
                                                        {
                                                            "type": "spacer",
                                                            "size": "sm",
                                                        }
                                                    ],
                                                    "flex": 0
                                                }
                                            }
                                        }
                                    ]
                                }
                                sendTemplate(to, data)
# Pembatas Script #                            
                            elif cmd == 'glist':
                            	if msg._from in Owner:
                                    groups = client.getGroupIdsJoined()
                                    ret_ = "╭──「 Group List」"
                                    no = 0 + 1
                                    for gid in groups:
                                        group = client.getGroup(gid)
                                        ret_ += "\n├≽ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                        no += 1
                                    ret_ += "\n╰──「 Total {} Groups 」".format(str(len(groups)))
                                    client.sendMessage(to, str(ret_))
                                    thread1 = Thread(target=client.sendMessage, args=(to, str(ret_)))

                            elif cmd.startswith("chat|"):
                                if msg._from in Owner:
                                    sep = text.replace("chat|","")
                                    bctxt = text.split("|")
                                    dan = bctxt[1]
                                    anu = bctxt[2]
                                    gr = client.getGroupIdsJoined()
                                    try:
                                        pesan = gr[int(dan)-1]
                                        group = client.getGroup(pesan)
                                        flexText(pesan, "╭──「 Admin Message」\n├≽ Kepada : {}\n├≽ Pesan : {} \n╰──「 Finish 」".format(group.name,str(anu)), "#0000FF")
                                        client.sendMessage(to, "Berhasil Kirim Pesan Ke Group : {}".format(group.name))
                                    except Exception as anu:
                                        client.sendMessage(to, str(anu))
                        
# Pembatas Script #
                            elif cmd.startswith("cname:"):
                            	if msg._from in Owner:
                                    sep = text.split(" ")
                                    string = text.replace(sep[0] + " ","")
                                    if len(string) <= 200:
                                        profile = client.getProfile()
                                        profile.displayName = string
                                        client.updateProfile(profile)
                                        client.sendMessage(to,"Berhasil mengganti display name menjadi{}".format(str(string)))
                                    
                            elif cmd.startswith("cbio:"):
                            	if msg._from in Owner:
                                    sep = text.split(" ")
                                    string = text.replace(sep[0] + " ","")
                                    if len(string) <= 500:
                                        profile = client.getProfile()
                                        profile.statusMessage = string
                                        client.updateProfile(profile)
                                        client.sendMessage(to,"Berhasil mengganti status message menjadi{}".format(str(string)))        
                                                                
                            elif cmd.startswith("byeall"):
                            	if msg._from in Owner:                            		
                            		gr = client.getGroupIdsJoined()
                            		for group in gr:
                            			client.sendMessage(group, "Disuruh keluar oleh Creator i'm sorry (ಥ_ಥ) silahkan reinvite 5 menit lagi\nmore info? http://line.me/ti/p/SGoaBN0jvC")
                            			client.leaveGroup(group)

                            elif cmd.startswith("invitetogc "):
                                if msg._from in Owner:
                                    sep = text.split(" ")
                                    query = text.replace(sep[0] + " ","")
                                    groups = client.getGroupIdsJoined()
                                    try:
                                         listGroup = groups[int(query)-1]
                                         group = client.getGroup(listGroup)
                                         client.inviteIntoGroup(group.id, [sender])
                                         sendMention(to, "Succesfully invite @! to Group {}".format(group.name), [sender])
                                    except Exception as error:
                                         logError(error)
                            
                            elif cmd.startswith("openqr:"):
                            	if msg._from in Owner:
                            		sep = text.split(":")
                            		anu = text.replace(sep[0] + ":","")
                            		gr = client.getGroupIdsJoined()
                            		try:
                            			group = gr[int(anu)-1]
                            			G = client.getGroup(group)
                            			G.preventedJoinByTicket = False
                            			client.updateGroup(G)
                            			client.sendMessage(to, "Sukses Membuka Qr Group : " + G.name)
                            			ticket = client.reissueGroupTicket(group)
                            			client.sendMessage(to, "╔══[ Group Ticket ]\n╠https://line.me/R/ti/g/{}\n╚══[ Finish ]".format(str(ticket)))
                            		except Exception as e:
                            			logError(e)

                            elif cmd == "myvideoprofile":
                            	if msg._from in Owner:
                                    contact = client.getContact(sender)
                                    client.sendVideoWithURL(to,"http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus))
                                    thread1 = Thread(target=client.sendVideoWithURL, args=(to, "http://dl.profile.line-cdn.net/{}/vp".format(contact.pictureStatus)))

                            elif cmd.startswith("unsend "):
                            	if msg._from in Owner:
                                    args = removeCmd("unsend", text)
                                    mes = 0
                                    try:
                                       mes = int(args[1])
                                    except:
                                        mes = 1
                                    M = client.getRecentMessagesV2(to, 101)
                                    MId = []
                                    for ind,i in enumerate(M):
                                        if ind == 0:
                                            pass
                                        else:
                                            if i._from == client.profile.mid:
                                                MId.append(i.id)
                                                if len(MId) == mes:
                                                    break
                                    def unsMes(id):
                                        client.unsendMessage(id)
                                    for i in MId:
                                        thread1 = threading.Thread(target=unsMes, args=(i,))
                                        thread1.start()
                                        thread1.join()
                                    client.sendMessage(to, ' Unsend {} message '.format(len(MId)))

                            elif text.lower().startswith("pcid"):
                                dan = text.split("|")
                                x = client.findContactsByUserid(dan[1])
                                a = client.getContact(sender)
                                flexText(x.mid, "Anda mendapatkan pesan dari "+a.displayName+"\n\n"+dan[2], "#0000FF")
                             #   client.sendMessage(x.mid,"Anda mendapatkan pesan dari "+a.displayName+"\n\n"+dan[2])
                                client.sendContact(x.mid, sender)
                                client.sendMessage(to,"Sukses mengirim pesan ke "+x.displayName+"\nDari: "+a.displayName+"\nPesan: "+dan[2])
                                    
                            elif cmd == "kick on":
                                if msg._from in Owner:
                                    wait["KickOn"] = True
                                    client.sendMessage(msg.to,"Status:\n{''cancel'':0,''kick'':1}")
                            elif cmd == "kick off":
                                if msg._from in Owner:
                                    wait["KickOn"] = False
                                    client.sendMessage(msg.to,"Status:\n{''cancel'':0,''kick'':0}")

                            elif 'Kickall' in msg.text:
                                if msg._from in Owner:
                                  if msg.toType == 2:
                                    if wait["KickOn"]:
                                        _name = msg.text.replace("Kickall","")
                                        gs = client.getGroup(msg.to)
                                        targets = []
                                        for g in gs.members:
                                            if _name in g.displayName:
                                                targets.append(g.mid)
                                        if targets == []:
                                            client.sendMessage(msg.to,"Target Not found.")
                                        else:
                                            for target in targets:
                                              if target not in Bots:
                                                try:
                                                    klist=[client]
                                                    kicker=random.choice(klist)
                                                    kicker.kickoutFromGroup(msg.to,[target])
                                                except Exception as error:
                                                    client.sendMessage(msg.to, str(error))

                            elif text.lower().startswith("balikkalimat") and sender == clientMid:
                                sep = text.split(" ")
                                sebelum = text.replace(sep[0]+" ","")
                                sesudah = sebelum[::-1]
                                client.sendMessage(to,"Sebelum : "+sebelum+"\nSesudah : "+sesudah )                
                                
                            elif cmd.startswith("searchyoutube"):
                                sep = text.split(" ")
                                search = text.replace(sep[0] + " ","")
                                r = requests.get("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=10&q={}&type=video&key=AIzaSyAF-_5PLCt8DwhYc7LBskesUnsm1gFHSP8".format(str(search)))
                                data = r.text
                                a = json.loads(data)
                                if a["items"] != []:
                                    ret_ = []
                                    yt = []
                                    for music in a["items"]:
                                        ret_.append({"thumbnailImageUrl": 'https://i.ytimg.com/vi/{}/maxresdefault.jpg'.format(music['id']['videoId']),"imageSize": "contain","imageAspectRatio": "square","title": '{}'.format(str(music['snippet']['title'][:40])),"text": '{}'.format(str(music['snippet']['channelTitle'][:15])),"actions": [{"type": "uri","label": "Go Page","uri": 'https://www.youtube.com/watch?v=' +music['id']['videoId']}]})
                                        yt.append('https://www.youtube.com/watch?v=' +music['id']['videoId'])
                                    k = len(ret_)//10
                                    for aa in range(k+1):
                                        data = {
                                            "access_token": client.authToken,
                                            "line_application": client.server.APP_NAME,
                                            "chat_id": msg.to,
                                            "messages": {
                                                "type": "template",
                                                "altText": "Youtube",
                                                "template": {
                                                    "type": "carousel",
                                                    "columns": ret_[aa*10 : (aa+1)*10]
                                                }
                                            }
                                        }
                                        sendTemplate(to, data)

                            elif text.lower().startswith("music "):
                              if msg._from in Owner:
                                try:
                                    search = text.lower().replace("music ","")
                                    r = requests.get("https://rest.farzain.com/api/joox.php?id={}&apikey=hHu5Tv54tFWtrJy7Sh4zU4ANz".format(urllib.parse.quote(search)))
                                    data = r.text
                                    data = json.loads(data)
                                    info = data["info"]
                                    audio = data["audio"]
                                    hasil = "[ Hasil Musik ]\n"
                                    hasil += "\n• Penyanyi : {}".format(str(info["penyanyi"]))
                                    hasil += "\n• Judul : {}".format(str(info["judul"]))
                                    hasil += "\n• Album : {}".format(str(info["album"]))
                                    hasil += "\n• Link : \n1. Image : {}".format(str(data["gambar"]))
                                    hasil += "\n• Link : \n2. MP3 : {}".format(str(audio["mp3"]))
                                    hasil += "\n• Link : \n3. M4A : {}".format(str(audio["m4a"]))
                                    client.sendImageWithURL(msg.to, str(data["gambar"]))
                                    client.sendMessage(msg.to, str(hasil))
                                    #client.sendMessage(msg.to, "Downloading...")
                                    #client.sendMessage(msg.to, " [ Result MP3 ] ")
                                    client.sendAudioWithURL(msg.to, str(audio["mp3"]))
                                    thread1 = Thread(target=client.sendAudioWithURL, args=(to, str(audio["mp3"])))
                                    #client.sendMessage(msg.to, " [ Result M4A ] ")
                                    client.sendVideoWithURL(msg.to, str(audio["m4a"]))
                                    thread1 = Thread(target=client.sendVideoWithURL, args=(to, str(audio["m4a"])))
                                    client.sendMessage(msg.to, str(data["lirik"]))
                                    #client.sendMessage(msg.to, "Success Download...")
                                except Exception as error:
                                    client.sendMessage(msg.to, " [ Result Error ]\n" + str(error))

                            elif cmd.startswith("image "):
                              if msg._from in Owner:
                                try:
                                    search = cmd.replace("image ","")
                                    r = requests.get("https://xeonwz.herokuapp.com/images/google.api?q={}".format(search))
                                    data = r.text
                                    data = json.loads(data)
                                    if data["content"] != []:
                                        items = data["content"]
                                        path = random.choice(items)
                                        a = items.index(path)
                                        b = len(items)
                                        client.sendImageWithURL(to, str(path))
                                        thread1 = Thread(target=client.sendImageWithURL, args=(to, str(path)))
                                except Exception as error:
                                     logError(error)
                                     var= traceback.print_tb(error.__traceback__)
                                     client.sendMessage(to,str(var))

                            elif cmd.startswith("stickerline "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("http://api.zicor.ooo/lstickers.php?search={}".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ Sticker Line ]"
                                for anu in data["items"]:
                                    no += 1
                                    result += "\n╠ {}. {}".format(str(no),str(anu["title"]))
                                    result += "\nhttps://store.line.me{}".format(str(anu["productUrl"]))
                                result += "\n╚══[ {} Sticker ]".format(str(len(data["items"])))
                                client.sendMessage(to, result)                            

                            elif cmd.startswith("ytdl "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                linkx = text.replace(sep[0] + " ", "")
                                if "/" in linkx:
                                   wew = linkx.split("/")
                                   linkx = wew[len(wew) - 1]
                                   r = requests.get("https://rest.farzain.com/api/yt_download.php?id=" + linkx + "&apikey=sD6OILe7zuYPCn7nuyynVDpIX", timeout=3)
                                   data = json.loads(r.text)
                                   client.sendMessage(to, str(data["urls"][0]["id"]))

                            elif cmd.startswith("chatowner "):
                                sep = text.split(" ")
                                bisma = text.replace(sep[0] + " ","")
                                contact = client.getContact(sender)
                                alfian = "u4033ea77038ab1a6ec89c42fe317f7ab"
                                ret_ = "Dari : @!"
                                ret_ += "\nSender : {}".format(contact.displayName)
                                ret_ += "\nPesanya : {}".format(bisma)
                                ret_ += "\nMid : {}".format(contact.mid)
                                client.sendMessage(to, "Succesfully send chat to Owner")
                                sendMention(alfian, ret_, [sender])
                                client.sendContact(alfian, sender)
                                
                            elif "Text " in msg.text:
                             	if msg._from in Owner:
                                     if 'MENTION' in msg.contentMetadata.keys()!= None:
                                         names = re.findall(r'@(\w+)', text)
                                         mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                         mentionees = mention['MENTIONEES']
                                         lists = []
                                         for mention in mentionees:
                                             if mention["M"] not in lists:
                                                 lists.append(mention["M"])
                                         for ls in lists:
                                             contact = client.getContact(ls)
                                         age = text.split(" ")
                                         age = text.replace(age[0]+" "," ")
                                         age = age.split('-')
                                         txt = str(age[0])
                                         client.unsendMessage(msg.id)
                                         client.sendMessage(msg.to,(txt),contentMetadata={"MSG_SENDER_NAME":"{}".format(str(contact.displayName)),"MSG_SENDER_ICON":"http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)})

                            elif cmd == "delmentionme":
                              if msg._from in Owner:
                                del tagme['ROM'][to]
                                client.sendReplyMessage(msg.id, to, "「DEL MENTIONME」\nBerhasil menghapus data Mention di group \n{}".format(client.getGroup(to).name))
                                
                            elif cmd == "mentionme":
                              if msg._from in Owner:
                                if to in tagme['ROM']:
                                  moneys = {}
                                  msgas = ''
                                  for a in tagme['ROM'][to].items():
                                    moneys[a[0]] = [a[1]['msg.id'],a[1]['waktu']] if a[1] is not None else idnya
                                  sort = sorted(moneys)
                                  sort.reverse()
                                  sort = sort[0:]
                                  msgas = '[Mention Me]'
                                  h = []
                                  no = 0
                                  for m in sort:
                                    has = ''
                                    nol = -1
                                    for kucing in moneys[m][0]:
                                      nol+=1
                                      has+= '\nline://nv/chatMsg?chatId={}&messageId={} \n{}'.format(to,kucing,humanize.naturaltime(datetime.fromtimestamp(moneys[m][1][nol]/1000)))
                                    h.append(m)
                                    no+=1
                                    if m == sort[0]:
                                      msgas+= '\n{}. @! {}x{} \n'.format(no,len(moneys[m][0]),has)
                                    else:
                                      msgas+= '\n{}. @! {}x{} \n'.format(no,len(moneys[m][0]),has)
                                  khieMention(to, msgas, h)
                                else:
                                  msgas = 'Maaf @! Di grup {} Belum ada data yang ngetag anda Bos Qu'.format(client.getGroup(to).name)
                                  khieMention(to, msgas, [sender])

                            elif cmd.startswith("themeline "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("http://api.zicor.ooo/ltheme.php?search={}".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ Theme Line ]"
                                for anu in data["items"]:
                                   no += 1
                                   result += "\n╠ {}. {}".format(str(no),str(anu["title"]))
                                   result += "\nhttps://store.line.me{}".format(str(anu["productUrl"]))
                                result += "\n╚══[ {} Tema ]".format(str(len(data["items"])))
                                client.sendMessage(to, result)

                            elif text.lower().startswith('instagram'):
                              if msg._from in Owner:
                                try:
                                    sep = text.split(" ")
                                    search = text.replace(sep[0] + " ","")
                                    r = requests.get("http://syadnysyz2.herokuapp.com/api/instagram/{}".format(search))
                                    data = r.json()
                                    a="Type: Search User Instagram\n"
                                    a+="\nName : "+str(data["graphql"]["user"]["full_name"])
                                    a+="\nUsername : "+str(data["graphql"]["user"]["username"])
                                    a+="\nBio : "+str(data["graphql"]["user"]["biography"])
                                    a+="\nUser Blocked : "+str(data["graphql"]["user"]["blocked_by_viewer"])
                                    a+="\nURL : "+str(data["graphql"]["user"]["external_url"])
                                    a+="\nURL link : "+str(data["graphql"]["user"]["external_url_linkshimmed"])
                                    a+="\nFollowers : "+str(data["graphql"]["user"]["edge_followed_by"]["count"])
                                    ##################a+="\nFollowing View : "+str(data["graphql"]["user"]["followed_by_viewer"])
                                    a+="\nFollowed : "+str(data["graphql"]["user"]["edge_follow"]["count"])
                                    ################a+="\nFollower View : "+str(data["graphql"]["user"]["follows_viewer"])
                                   #a+="\nChannel  : "+str(data["graphql"]["user"]["has_channel"])
                                   # a+="\nBlocked Viewer : "+str(data["graphql"]["user"]["has_blocked_viewer"])
                                    ###############a+="\nReal Account : "+str(data["graphql"]["user"]["highlight_reel_count"])
                                    #################a+="\nRequest Viewer : "+str(data["graphql"]["user"]["has_requested_viewer"])
                                    #################a+="\nId : "+str(data["graphql"]["user"]["id"])
                                    ##################a+="\nBussines Account : "+str(data["graphql"]["user"]["is_business_account"])
                                    a+="\nPrivate Account : "+str(data["graphql"]["user"]["is_private"])
                                    a+="\nVerified : "+str(data["graphql"]["user"]["is_verified"])
                                    #################a+="\nFollow Real Account : "+str(data["graphql"]["user"]["edge_mutual_followed_by"]["count"])
                                    #################a+="\nPicture url : "+str(data["graphql"]["user"]["profile_pic_url"])
                                    ###############a+="\nPicture url HD : "+str(data["graphql"]["user"]["profile_pic_url_hd"])
                                    ##################a+="\nConnected Facebook : "+str(data["graphql"]["user"]["connected_fb_page"])
                                    ################a+="\nRequested View : "+str(data["graphql"]["user"]["requested_by_viewer"])                                
                                    client.sendMessage(to,a)
                                except Exception as e:
                                    client.sendMessage(to, str(e))

                            elif text.lower().startswith('artisifatnama'):
                                try:
                                    sep = text.split(" ")
                                    search = text.replace(sep[0] + " ","")
                                    r = requests.get("http://syadnysyz2.herokuapp.com/api/ramalan-nama?nama=/{}".format(search))
                                    data = r.json()
                                    a=" Type: Ramalan Nama\n"
                                    a+="\nRomantis : "+str(data["result"]["romantis"])
                                    a+="\nMesum : "+str(data["result"]["mesum"])
                                    a+="\nMiris : "+str(data["result"]["miris"])
                                    a+="\nTulus : "+str(data["result"]["tulus"])
                                    a+="\nLoyal : "+str(data["result"]["loyal"])
                                    client.sendMessage(to,a)
                                except Exception as e:
                                    client.sendMessage(to, str(e))

                            elif text.lower().startswith('artinama'):
                                try:
                                    sep = text.split(" ")
                                    search = text.replace(sep[0] + " ","")
                                    r = requests.get("http://syadnysyz2.herokuapp.com/api/ramalan-primbon/artinama?nama=/{}".format(search))
                                    data = r.json()
                                    a=" 「 Fun 」\nType: Arti Nama\n"
                                    a+="\nRomantis : "+str(data["arti"])
                                    client.sendMessage(to,a)
                                except Exception as e:
                                    client.sendMessage(to, str(e))

                            elif cmd.startswith("samehadaku "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/samehadaku.php?id={}&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ ~ Samehadaku ~ ]"
                                for anu in data:
                                    no += 1
                                    result += "\n╠ {}. {}".format(str(no),str(anu["title"]))
                                    result += "\n╠ {}".format(str(anu["url"]))
                                    result += "\n╠ {}".format(str(anu["date"]))
                                result += "\n╚══[ {} Anime ]".format(str(len(data)))
                                client.sendMessage(to, result)
                                
                            elif cmd.startswith("brainly "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/brainly.php?id={}&apikey=oQ61nCJ2YBIP1qH25ry6cw2ba".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ ~ Brainly ~ ]"
                                for anu in data:
                                    no += 1
                                    result += "\n╠ {}. {}".format(str(no),str(anu["title"]))
                                    result += "\n╠ {}".format(str(anu["url"]))
                                result += "\n╚══[ ~ {} Answer ~ ]".format(str(len(data)))
                                client.sendMessage(to, result)
                                
                            elif cmd.startswith("harinasional "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://rest.farzain.com/api/special/tanggal.php?id={}&type=nasional&apikey=ppqeuy".format(txt))
                                data = url.json()
                                no = 0
                                result = "╔══[ ~ HariNasional Indonesia ~ ]"
                                for anu in data["result"]:
                                    no += 1
                                    result += "\n╠ {}. {}".format(str(no),str(anu["tanggal"]))
                                    result += "\n╠ Keterangan {}".format(str(anu["keterangan"]))
                                result += "\n╚══[ ~ {} Hari Nasional ~ ]".format(str(len(data["result"])))
                                client.sendMessage(to, result)

                            elif cmd.startswith("fsviloid "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = "https://rest.farzain.com/api/special/fansign/indo/viloid.php?apikey=ppqeuy&text={}".format(txt)
                                client.sendImageWithURL(to, url)

                            elif cmd.startswith("fscosplay "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = "https://rest.farzain.com/api/special/fansign/cosplay/cosplay.php?apikey=ppqeuy&text={}".format(txt)
                                client.sendImageWithURL(to, url)                            

                            elif cmd.startswith("leavegc "):
                            	if msg._from in Owner:
                            		sep = text.split(" ")
                            		search = text.replace(sep[0] + " ","")
                            		gr = client.getGroupIdsJoined()
                            		try:
                            			group = gr[int(search)-1]
                            			gid = client.getGroup(group)
                            			client.sendMessage(group, "Disuruh Leave Oleh Creator Khusus Group {}".format(gid.name))
                            			client.leaveGroup(group)
                            			client.sendMessage(to, "Sukses Leave Dari Group " + gid.name)
                            		except Exception as e:
                            			client.sendMessage(to, str(e))

                            elif cmd == "mention":
                              if msg._from in Owner:
                                group = client.getGroup(to)
                                midMembers = [contact.mid for contact in group.members]
                                midSelect = len(midMembers)//20
                                for mentionMembers in range(midSelect+1):
                            	    no = 0
                            	    ret_ = "╭═─「 List Member 」"
                            	    dataMid = []
                            	    for dataMention in group.members[mentionMembers*20 : (mentionMembers+1)*20]:
                            		    dataMid.append(dataMention.mid)
                            		    no += 1
                            		    ret_ += "\n├≽ {}. @!".format(str(no))
                            	    ret_ += "\n╰═─≽「 Result {} Members 」".format(str(len(dataMid)))
                            	    sendMention(to, ret_, dataMid)                                    

                            elif cmd.startswith("downloadyt"):
                              if msg._from in Owner:
                                try:
                                    sep = msg.text.split(" ")
                                    kudanil = text.replace(sep[0] + " ","")
                                    r = requests.get("http://api.farzain.com/yt_download.php?id={}&apikey=hHu5Tv54tFWtrJy7Sh4zU4ANz".format(kudanil))
                                    data = r.text
                                    data = json.loads(data)
                                    client.sendVideoWithURL(msg.to, str(data["urls"][0]["id"]))
                                except Exception as e:
                                    client.sendMessage(msg.to, str(e))

                            elif cmd.startswith("whois "):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                txt = text.replace(sep[0] + " ","")
                                url = requests.get("https://arsybaiapi.herokuapp.com/knowledge={}".format(txt))
                                data = url.json()
                                contact = client.getContact(sender)
                                no = 0
                                result = "╔══[{}]".format(contact.displayName)
                                anu = data["result"]
                                no += 1
                                result += "\n╠ {}. {}".format(str(no),(anu["name"]))
                                result += "\n╠ Url = {}".format(anu["url"])
                                result += "\n╠ Artikel = {}".format(anu["article"])
                                result += "\n╠ Deskripsi = {}".format(anu["description"])
                                result += "\n╚══[ {} ]".format(anu["name"])
                                client.sendMessage(to, result)
                                client.sendImageWithURL(to, anu["img"])                             

                            elif cmd.startswith('ssweb'):
                              if msg._from in Owner:
                                sep = text.split(" ")
                                query = text.replace(sep[0] + " ","")
                                r = "https://image.thum.io/get/width/1200/http://{}".format(query)
                                client.sendImageWithURL(receiver, r)

                            elif cmd.startswith("animequotes"):
                              if msg._from in Owner:
                                try:
                                    sep = text.split(" ")
                                    r = requests.get("https://rest.farzain.com/api/animequotes.php?apikey=hHu5Tv54tFWtrJy7Sh4zU4ANz")
                                    data = r.text
                                    data = json.loads(data)
                                    ret_ = "●Quote : "+ str(data["result"]["quote"])
                                    ret_ += "\n\n●Author : "+ str(data["result"]["author"])
                                    ret_ += "\n\n●Anime : "+ str(data["result"]["anime"])
                                    client.sendMessage(msg.to, str(ret_))
                                except Exception as error:
                                    client.sendMessage(to, "error\n" + str(error))
                                    logError(error)
                            
                            elif cmd.startswith("fmylife"):
                              if msg._from in Owner:
                                result = requests.get("http://www.fmylife.com/random")
                                data = BeautifulSoup(result.content, 'html5lib')                                                                             
                                for sam in data.findAll('figure', attrs={'class':'text-center visible-xs'}):                                        
                                    path = str(sam.find('img')['data-src'])                                    
                                client.sendImageWithURL(to, str(path))
                                thread1 = Thread(target=client.sendImageWithURL, args=(to, str(path)))

                            elif cmd.startswith("motivate"):
                              if msg._from in Owner:
                                r = requests.get("https://talaikis.com/api/quotes/random")
                                data=r.text
                                data=json.loads(data)                                                                   
                                client.sendMessage(to,str(data["quote"]))
     
                            elif cmd == "bitcoin" or cmd == " bitcoin":
                              if msg._from in Owner:
                                r=requests.get("https://xeonwz.herokuapp.com/bitcoin.api")
                                data=r.text
                                data=json.loads(data)
                                hasil = "「 Bitcoin 」\n" 
                                hasil += "\nPrice : " +str(data["btc"])
                                hasil += "\nExpensive : " +str(data["high"])
                                hasil += "\nCheap : " +str(data["low"])
                                client.sendMessage(msg.to, str(hasil))  

                            elif cmd.startswith("topnews"):
                              if msg._from in Owner:
                                try:
                                    api_key = "a53cb61cee4d4c518b69473893dba73b"
                                    r = _session.get("https://newsapi.org/v2/top-headlines?country=id&apiKey={}".format(str(api_key)))
                                    data = r.text
                                    data = json.loads(data)
                                    ret_ = "Top News"
                                    no = 1
                                    anu = data["articles"]
                                    if len(anu) >= 5:
                                        for s in range(5):
                                            syit = anu[s]
                                            sumber = syit['source']['name']
                                            author = syit['author']
                                            judul = syit['title']
                                            url = syit['url']
                                            ret_ += "\n\n{}. Judul : {}\n    Sumber : {}\n    Penulis : {}\n    Link : {}".format(str(no), str(judul), str(sumber), str(author), str(url))
                                            no += 1
                                    else:
                                         for s in anu:
                                            syit = s
                                            sumber = syit['source']['name']
                                            author = syit['author']
                                            judul = syit['title']
                                            url = syit['url']
                                            ret_ += "\n\n{}. Judul : {}\n    Sumber : {}\n    Penulis : {}\n    Link : {}".format(str(no), str(judul), str(sumber), str(author), str(url))
                                            no += 1
                                    client.sendMessage(to, str(ret_))
                                except:
                                    client.sendMessage(to, "Porn Not Found !")

                            elif cmd.startswith("top kaskus"):
                              if msg._from in Owner:
                                r = requests.get("https://api.bayyu.net/kaskus-hotthread/?apikey=c28c944199384f191335f1f8924414fa839350d&page=2")
                                data=r.text
                                data=json.loads(data)                                                                                                      
                                if data["hot_threads"] != []:
                                    no = 0
                                    hasil = " Kaskus Search \n"
                                    for news in data["hot_threads"]:
                                          no += 1                  
                                          hasil += "\n" + str(no) + ". Judul : " + str(news["title"]) + "\n  Deskripsi : " + str(news["detail"]) + "\n Link: " + str(news["link"]) + "\n"
                                          hasil += "\n"
                                    client.sendMessage(msg.to, str(hasil))      
         
                            elif cmd.startswith("wallpaper-hd "):
                              if msg._from in Owner:
                                sep = msg.text.split(" ")
                                nama = msg.text.replace(sep[0] + " ","")
                                cond = nama.split(":")
                                key = str(cond[0])
                                caps = key.upper()
                                client.sendMessage(msg.to, "Sedang Mencari Data...")
                                webnya = requests.get("https://api.eater.pw/wallp/"+key)
                                data = webnya.text
                                data = json.loads(data)
                                no=0
                                hasil="[ RESULT WALLPAPER HD "+caps+" ]\n\n"
                                if len(cond) == 1:
                                    for nadia in data["result"]:
                                        no+=1
                                        hasil+="{}. {}\n".format(str(no), str(nadia["judul"]))
                                        ret_="\nSelanjutnya ketik :\nWallpaper-hd "+key+":nomor list\nUntuk melihat detail video"
                                    client.sendMessage(msg.to, str(hasil)+ret_)
                                elif len(cond) == 2:
                                    no = int(cond[1])
                                    if no <= len(data["result"]):                                       
                                        gambar = data["result"][no - 1]
                                        client.sendMessage(msg.to, "Judul : "+str(gambar["judul"]))
                                        client.sendImageWithURL(msg.to, str(gambar["link"]))                                          
 
                            elif cmd.startswith("asking "):
                              if msg._from in Owner:
                                kata = removeCmd("asking", text)
                                sch = kata.replace(" ","+")
                                with _session as web:
                                    urlz = "http://lmgtfy.com/?q={}".format(str(sch))
                                    r = _session.get("http://tiny-url.info/api/v1/create?apikey=A942F93B8B88C698786A&provider=cut_by&format=json&url={}".format(str(urlz)))
                                    data = r.text
                                    data = json.loads(data)
                                    url = data["shorturl"]
                                    ret_ = "Ask"
                                    ret_ += "\n\nLink : {}".format(str(url))
                                    client.sendMessage(to, str(ret_))

                            elif cmd.startswith("deviantart "):
                              if msg._from in Owner:
                                try:
                                    search = cmd.replace("devianart ","")
                                    r = requests.get("https://xeonwz.herokuapp.com/images/deviantart.api?q={}".format(search))
                                    data = r.text
                                    data = json.loads(data)
                                    if data["content"] != []:
                                        items = data["content"]
                                        path = random.choice(items)
                                        a = items.index(path)
                                        b = len(items)
                                        client.sendImageWithURL(to, str(path))
                                        thread1 = Thread(target=client.sendImageWithURL, args=(to, str(path)))
                                except Exception as error:
                                    logError(error)
                                    var= traceback.print_tb(error.__traceback__)
                                    client.sendMessage(to,str(var))                                                      
 
                            elif cmd.startswith("creepypasta"):
                              if msg._from in Owner:
                                r=requests.get("http://hipsterjesus.com/api")
                                data=r.text
                                data=json.loads(data)
                                hasil = "「 Creepypasta 」\n" 
                                hasil += str(data["text"])
                                client.sendMessage(msg.to, str(hasil))

                            elif cmd.startswith("imageart "):
                              if msg._from in Owner:
                                try:                                   
                                    search = cmd.replace("imageart ","")
                                    r = requests.get("https://xeonwz.herokuapp.com/images/deviantart.api?q={}".format(search))
                                    data = r.text
                                    data = json.loads(data)
                                    if data["content"] != []:
                                        items = data["content"]
                                        path = random.choice(items)
                                        a = items.index(path)
                                        b = len(items)
                                        client.sendImageWithURL(to, str(path))
                                        client.sendMessage(to,"Art #%s from #%s." %(str(a),str(b)))
                                        log.info("Art #%s from #%s." %(str(a),str(b)))
                                except Exception as error:
                                    log.info(error)

                            elif cmd.startswith("neon: "):
                              if msg._from in Owner:
                                try:
                                     txt = msg.text.split(" ")
                                     teks = msg.text.lower().replace("neon: ","")
                                     color = ["red","yellow","green","purple","violet","blue"]
                                     k = random.choice(color)
                                     foto = "https://ari-api.herokuapp.com/neon?text="+teks+"&color="+k+""
                                     sendMentionV2(msg.to, "@! ini foto neon pesanan kamu..", [msg._from])
                                     client.sendImageWithURL(msg.to, foto)
                                except Exception as e:
                                     client.sendMessage(msg.to, str(e))

                            elif cmd.startswith("zodiaceng ") and sender == clientMid:
                              if msg._from in Owner:
                                string = cmd.replace("zodiaceng ","")   
                                r=requests.get("http://horoscope-api.herokuapp.com/horoscope/week/{}".format(str(string)))
                                data=r.text
                                data=json.loads(data)
                                hasil="Zodiac Result:\n"
                                hasil += "\nZodiac: " +str(data["sunsign"])
                                hasil += "\n\n"+str(data["horoscope"])
                                hasil += "\n\nDate: " +str(data["week"])                                                                                                                                                          
                                client.sendMessage(to,str(hasil))

                            elif cmd.startswith("timezone "):
                              if msg._from in Owner:
                                try:
                                    search = cmd.replace("timezone ","")
                                    r = requests.get("https://time.siswadi.com/geozone/{}".format(urllib.parse.quote(search)))
                                    data=r.text
                                    data=json.loads(data)
                                    ret_ = "「 Timezone 」\n"
                                    ret_ += "\nLatitude : " +str(data["data"]["latitude"])
                                    ret_ += "\nLongitude : " +str(data["data"]["longitude"])
                                    ret_ += "\nAddress : " +str(data["data"]["address"])
                                    ret_ += "\nCountry : " +str(data["data"]["country"])
                                    client.sendMessage(to, str(ret_))
                                except Exception as error:
                                   client.sendMessage(to, str(error))

                            elif cmd.startswith("zodiacind "):
                              if msg._from in Owner:
                                sep = msg.text.split(" ")
                                url = msg.text.replace(sep[0] + " ","")    
                                with requests.session() as s:
                                    s.headers['user-agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
                                    r = s.get("https://www.vemale.com/zodiak/{}".format(urllib.parse.quote(url)))
                                    soup = BeautifulSoup(r.content, 'html5lib')
                                    ret_ = ""
                                    for a in soup.select('div.vml-zodiak-detail'):
                                        ret_ += a.h1.string
                                        ret_ += "\n"+ a.h4.string
                                        ret_ += " : "+ a.span.string +""
                                    for b in soup.select('div.col-center'):
                                        ret_ += "\nTanggal : "+ b.string
                                    for d in soup.select('div.number-zodiak'):
                                        ret_ += "\nAngka keberuntungan : "+ d.string
                                    for c in soup.select('div.paragraph-left'):
                                        ta = c.text
                                        tab = ta.replace("    ", "")
                                        tabs = tab.replace(".", ".\n")
                                        ret_ += "\n"+ tabs
                                        #print (ret_)
                                        client.sendMessage(msg.to, str(ret_))
                                                       
                            elif cmd.startswith("missing-"):
                                settings["image"]["imagetomis"].append(to) 
                                sep = msg.text.split("-")
                                settings['text1'] = sep[1]
                                settings['text2'] = sep[2]
                                settings['text3'] = sep[3]
                                client.sendReplyMessage(msg.id,to,"Send Image.....")
                                
                            elif cmd == "fight":
                              if msg._from in Owner:
                                group = client.getGroup(to)
                                try:
                                    members = [mem.mid for mem in group.members]
                                    mortal = [mem.mid for mem in group.members]
                                except:
                                    members = [mem.mid for mem in group.members]
                                    mortal = [mem.mid for mem in group.members]
                                s = random.choice(members)
                                t = random.choice(mortal)
                                bis = "Mortal Kombat has been initiated. "+client.getContact(s).displayName+" must fight..."+client.getContact(t).displayName+"! FIGHTO!"                                    
                                client.sendMessage(to,str(bis))
                             
                            elif cmd.startswith("calc "):
                                query = cmd.replace("calc ","")
                                r=requests.get("https://www.calcatraz.com/calculator/api?c={}".format(urllib.parse.quote(query)))
                                data=r.text
                                data=json.loads(data)
                                client.sendMessage(msg.to, query + " = " + str(data))
                                
                            elif cmd.startswith("kode cctv"):
                              if msg._from in Owner:
                                ret_ = "Daftar Kode Wilayah:\n\n"
                                ret_ += "248 = Alternatif - Cibubur\n119 = Ancol - bandara\n238 = Asia afrika - Bandung\n169 = Asia afrika - Hang lekir"
                                ret_ += "\n276 = Asia afrika - Sudirman\n295 = Bandengan - kota\n294 = Bandengan - Selatan\n255 = Boulevard Barat raya"
                                ret_ += "\n102 = Buncit raya\n272 = Bundaran - HI\n93 = Cideng barat\n289 = Cikini raya\n242 = Ciledug raya - Cipulir"
                                ret_ += "\n175 = Ciloto - Puncak\n142 = Daan mogot - Grogol\n143 = Daan mogot - Pesing\n338 = Dewi sartika - Cawang"
                                ret_ += "\n124 = DI Panjaitan - By pass\n123 = DI Panjaitan - Cawang\n13 = Dr Satrio - Casablanca\n105 = Dr Satrio - Karet"
                                ret_ += "\n245 = Dukuh atas - MRT Jakarta\n334 = Fachrudin raya\n252 = Fatmawati - Blok A\n253 = Fatmawati - Cipete raya"
                                ret_ += "\n203 = Flyover Daan mogot\n336 = Flyover Jati baru\n172 = Flyover Senen - Kramat\n77 = Gunung sahari"
                                ret_ += "\n137 = Hasyim Ashari\n273 = Jalan MH Thamrin\n327 = Jalan RS Fatmawati\n292 = Jl. Otista 3\n333 = Jl. Panjang - Kebon jeruk"
                                ret_ += "\n226 = JORR - Bintaro\n227 = JORR - Fatmawati\n173 = Kramat raya - Senen\n117 = Kyai Caringin - Cideng\n126 = Letjen Suprapto - Senen"
                                ret_ += "\n204 = Mangga besar\n319 = Margaguna raya\n326 = Margonda raya\n310 = Mas Mansyur - Karet\n309 = Mas Mansyur - Tn. Abang"
                                ret_ += "\n64 = Matraman\n140 = Matraman - Salemba\n284 = Metro Pdk. Indah\n191 = MT Haryono - Pancoran\n160 = Pancoran barat"
                                ret_ += "\n331 = Pejompongan - Slipi\n332 = Pejompongan - Sudirman\n312 = Perempatan pramuka\n171 = Permata hijau - Panjang\n99 = Petojo Harmoni"
                                ret_ += "\n223 = Pramuka - Matraman\n222 = Pramuka raya\n314 = Pramuka raya - jl. Tambak\n313 = Pramuka - Salemba raya\n130 = Puncak raya KM84"
                                ret_ += "\n318 = Radio dalam raya\n328 = RS Fatmawati - TB\n274 = Senayan city\n132 = Slipi - Palmerah\n133 = Slipi - Tomang"
                                ret_ += "\n162 = S Parman - Grogol\n324 = Sudirman - Blok M\n18 = Sudirman - Dukuh atas\n325 = Sudirman - Semanggi\n112 = Sudirman - Setiabudi"
                                ret_ += "\n246 = Sudirman - Thamrin\n320 = Sultan agung - Sudirman\n100 = Suryo pranoto\n220 = Tanjung duren\n301 = Tol kebon jeruk"
                                ret_ += "\n41 = Tomang/Simpang\n159 = Tugu Pancoran\n145 = Warung jati - Pejaten\n205 = Yos Sudarso - Cawang\n206 = Yos Sudarso - Tj. Priuk"
                                ret_ += "\n\nUntuk melihat cctv!\nKetik {}lihat: (no kode)".format(str(settings["keyCommand"]))                          
                                #client.sendReplyMessage(msg_id, to, ret_)
                                flexHelp(to, ret_)
                                
                            elif cmd.startswith("lihat: "):
                              if msg._from in Owner:
                                sep = msg.text.split(" ")
                                cct = msg.text.replace(sep[0] + " ","")
                                with requests.session() as s:
                                    s.headers['user-agent'] = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
                                    r = s.get("http://lewatmana.com/cam/{}/bundaran-hi/".format(str(urllib.parse.quote(cct))))
                                    soup = BeautifulSoup(r.content, 'html5lib')
                                    try:
                                        ret_ = "Info cctv:\n\n• Area: "
                                        ret_ += soup.select("[class~=cam-viewer-title]")[0].text
                                        ret_ += "\n\nUntuk hasil lain ketik {}: no ♪".format(str(settings["keyCommand"]))
                                        vid = soup.find('source')['src']
                                        client.sendReplyMessage(msg_id, to, ret_)
                                        client.sendVideoWithURL(to, vid)
                                    except:
                                    	client.sendReplyMessage(msg_id, to, "Data cctv tidak ditemukan!")
                                    
                            elif cmd.startswith("randomnumber "):                              
                              if msg._from in Owner:
                                  separate = msg.text.split(" ")
                                  angka = msg.text.replace(separate[0] + " ","")  
                                  tgb = angka.split("-")
                                  num1 = tgb[0]
                                  num2 = tgb[1]
                                  r = requests.get("https://farzain.com/api/random.php?min="+num1+"&max="+num2)
                                  data = r.json()
                                  client.sendMessage(msg.to,"Hasil : "+str(data["url"]))
                                  
                            elif cmd == "listquran":
                              if msg._from in Owner:
                                  ret_ = "List Al-Quran:"
                                  ret_ += "\n╭━━━━━╦╦━━━━━╮"
                                  ret_ += "\n⏺1. Al-Faatiha"
                                  ret_ += "\n⏺2. Al-Baqara"
                                  ret_ += "\n⏺3. Aal-i-Imraan"
                                  ret_ += "\n⏺4. An-Nisaa"
                                  ret_ += "\n⏺5. Al-Maaida"
                                  ret_ += "\n⏺6. Al-An'aam"
                                  ret_ += "\n⏺7. Al-A'raaf"
                                  ret_ += "\n⏺8. Al-Anfaal"
                                  ret_ += "\n⏺9. At-Tawba"
                                  ret_ += "\n⏺10. Yunus"
                                  ret_ += "\n⏺11. Hud"
                                  ret_ += "\n⏺12. Yusuf"
                                  ret_ += "\n⏺13. Ar-Ra'd"
                                  ret_ += "\n⏺14. Ibrahim"
                                  ret_ += "\n⏺15. Al-Hijr"
                                  ret_ += "\n⏺16. An-Nahl"
                                  ret_ += "\n⏺17. Al-Israa"
                                  ret_ += "\n⏺18. Al-Kahf"
                                  ret_ += "\n⏺19. Maryam"
                                  ret_ += "\n⏺20. Taa-Haa"
                                  ret_ += "\n⏺21. Al-Anbiyaa"
                                  ret_ += "\n⏺22. Al-Hajj"
                                  ret_ += "\n⏺23. Al-Muminoon"
                                  ret_ += "\n⏺24. An-Noor"
                                  ret_ += "\n⏺25. Al-Furqaan"
                                  ret_ += "\n⏺26. Ash-Shu'araa"
                                  ret_ += "\n⏺27. An-Naml"
                                  ret_ += "\n⏺28. Al-Qasas"
                                  ret_ += "\n⏺29. Al-Ankaboot"
                                  ret_ += "\n⏺30. Ar-Room"
                                  ret_ += "\n⏺31. Luqman"
                                  ret_ += "\n⏺32. As-Sajda"
                                  ret_ += "\n⏺33. Al-Ahzaab"
                                  ret_ += "\n⏺34. Saba"
                                  ret_ += "\n⏺35. Faatir"
                                  ret_ += "\n⏺36. Yaseen"
                                  ret_ += "\n⏺37. As-Saaffaat"
                                  ret_ += "\n⏺38. Saad"
                                  ret_ += "\n⏺39. Az-Zumar"
                                  ret_ += "\n⏺40. Ghafir"
                                  ret_ += "\n⏺41. Fussilat"
                                  ret_ += "\n⏺42. Ash-Shura"
                                  ret_ += "\n⏺43. Az-Zukhruf"
                                  ret_ += "\n⏺44. Ad-Dukhaan"
                                  ret_ += "\n⏺45. Al-Jaathiya"
                                  ret_ += "\n⏺46. Al-Ahqaf"
                                  ret_ += "\n⏺47. Muhammad"
                                  ret_ += "\n⏺48. Al-Fath"
                                  ret_ += "\n⏺49. Al-Hujuraat"
                                  ret_ += "\n⏺50. Qaaf"
                                  ret_ += "\n⏺51. Adh-Dhaariyat"
                                  ret_ += "\n⏺52. At-Tur"
                                  ret_ += "\n⏺53. An-Najm"
                                  ret_ += "\n⏺54. Al-Qamar"
                                  ret_ += "\n⏺55. Ar-Rahmaan"
                                  ret_ += "\n⏺56. Al-Waaqia"
                                  ret_ += "\n⏺57. Al-Hadid"
                                  ret_ += "\n⏺58. Al-Mujaadila"
                                  ret_ += "\n⏺59. Al-Hashr"
                                  ret_ += "\n⏺60. Al-Mumtahana"
                                  ret_ += "\n⏺61. As-Saff"
                                  ret_ += "\n⏺62. Al-Jumu'a"
                                  ret_ += "\n⏺63. Al-Munaafiqoon"
                                  ret_ += "\n⏺64. At-Taghaabun"
                                  ret_ += "\n⏺65. At-Talaaq"
                                  ret_ += "\n⏺66. At-Tahrim"
                                  ret_ += "\n⏺67. Al-Mulk"
                                  ret_ += "\n⏺68. Al-Qalam"
                                  ret_ += "\n⏺69. Al-Haaqqa"
                                  ret_ += "\n⏺70. Al-Ma'aarij"
                                  ret_ += "\n⏺71. Nooh"
                                  ret_ += "\n⏺72. Al-Jinn"
                                  ret_ += "\n⏺73. Al-Muzzammil"
                                  ret_ += "\n⏺74. Al-Muddaththir"
                                  ret_ += "\n⏺75. Al-Qiyaama"
                                  ret_ += "\n⏺76. Al-Insaan"
                                  ret_ += "\n⏺77. Al-Mursalaat"
                                  ret_ += "\n⏺78. An-Naba"
                                  ret_ += "\n⏺79. An-Naazi'aat"
                                  ret_ += "\n⏺80. Abasa"
                                  ret_ += "\n⏺81. At-Takwir"
                                  ret_ += "\n⏺82. Al-Infitaar"
                                  ret_ += "\n⏺83. Al-Mutaffifin"
                                  ret_ += "\n⏺84. Al-Inshiqaaq"
                                  ret_ += "\n⏺85. Al-Burooj"
                                  ret_ += "\n⏺86. At-Taariq"
                                  ret_ += "\n⏺87. Al-A'laa"
                                  ret_ += "\n⏺88. Al-Ghaashiya"
                                  ret_ += "\n⏺89. Al-Fajr"
                                  ret_ += "\n⏺90. Al-Balad"
                                  ret_ += "\n⏺91. Ash-Shams"
                                  ret_ += "\n⏺92. Al-Lail"
                                  ret_ += "\n⏺93. Ad-Dhuhaa"
                                  ret_ += "\n⏺94. Ash-Sharh"
                                  ret_ += "\n⏺95. At-Tin"
                                  ret_ += "\n⏺96. Al-Alaq"
                                  ret_ += "\n⏺97. Al-Qadr"
                                  ret_ += "\n⏺98. Al-Bayyina"
                                  ret_ += "\n⏺99. Az-Zalzala"
                                  ret_ += "\n⏺100. Al-Aadiyaat"
                                  ret_ += "\n⏺101. Al-Qaari'a"
                                  ret_ += "\n⏺102. At-Takaathur"
                                  ret_ += "\n⏺103. Al-Asr"
                                  ret_ += "\n⏺104. Al-Humaza"
                                  ret_ += "\n⏺105. Al-Fil"
                                  ret_ += "\n⏺106. Quraish"
                                  ret_ += "\n⏺107. Al-Maa'un"
                                  ret_ += "\n⏺108. Al-Kawthar"
                                  ret_ += "\n⏺109. Al-Kaafiroon"
                                  ret_ += "\n⏺110. An-Nasr"
                                  ret_ += "\n⏺111. Al-Masad"
                                  ret_ += "\n⏺112. Al-Ikhlaas"
                                  ret_ += "\n⏺113. Al-Falaq"
                                  ret_ += "\n⏺114. An-Naas"
                                  ret_ += "\n╰━━╩ɪsʟᴀᴍ ɪᴛᴜ ɪɴᴅᴀʜ╩━━╯"
                                  ret_ += "\n\nKetik:\n    • {}quran: (no)".format(str(settings["keyCommand"]))
                                  ret_ += "\n    • {}quranmp3: (no)".format(str(settings["keyCommand"]))
                                  client.sendReplyMessage(msg_id, to, str(ret_))
                                  
                            elif cmd.startswith("quranmp3:"):
                                try:
                                    sep = msg.text.split(" ")
                                    surah = int(text.replace(sep[0] + " ",""))
                                    if 0 < surah < 115:
                                        if surah not in [3, 4, 5, 6, 7, 9, 10, 11, 12, 16, 17, 18, 20, 21, 23, 26, 37]:
                                            if len(str(surah)) == 1:
                                                audionya = "https://audio5.qurancentral.com/mishary-rashid-alafasy/mishary-rashid-alafasy-00" + str(surah) + "-muslimcentral.com.mp3"
                                                link = ["https://lh5.googleusercontent.com/-MEKINv1_wgE/UF7PBtTA70I/AAAAAAAAAH8/hapvD5ztXY0/s800/Wallpaper%2520Alquran%2520Bergerak%2520Bercahaya.gif"]
                                                pilih = random.choice(link)
                                                client.sendImageWithURL(msg.to,pilih)
                                                client.sendAudioWithURL(to, audionya)
                                                client.sendReplyMessage(msg_id, to, "➥ɪsʟᴀᴍ ɪᴛᴜ ɪɴᴅᴀʜ")
                                            elif len(str(surah)) == 2:
                                                audionya = "https://audio5.qurancentral.com/mishary-rashid-alafasy/mishary-rashid-alafasy-0" + str(surah) + "-muslimcentral.com.mp3"
                                                link = ["https://lh5.googleusercontent.com/-MEKINv1_wgE/UF7PBtTA70I/AAAAAAAAAH8/hapvD5ztXY0/s800/Wallpaper%2520Alquran%2520Bergerak%2520Bercahaya.gif"]
                                                pilih = random.choice(link)
                                                client.sendImageWithURL(msg.to,pilih)
                                                client.sendAudioWithURL(to, audionya)
                                                client.sendReplyMessage(msg_id, to, "➥ɪsʟᴀᴍ ɪᴛᴜ ɪɴᴅᴀʜ")
                                            else:
                                                audionya = "https://audio5.qurancentral.com/mishary-rashid-alafasy/mishary-rashid-alafasy-" + str(surah) + "-muslimcentral.com.mp3"
                                                link = ["https://lh5.googleusercontent.com/-MEKINv1_wgE/UF7PBtTA70I/AAAAAAAAAH8/hapvD5ztXY0/s800/Wallpaper%2520Alquran%2520Bergerak%2520Bercahaya.gif"]
                                                pilih = random.choice(link)
                                                client.sendImageWithURL(msg.to,pilih)
                                                client.sendAudioWithURL(to, audionya)
                                                client.sendReplyMessage(msg_id, to, "➥ɪsʟᴀᴍ ɪᴛᴜ ɪɴᴅᴀʜ")
                                        else:
                                            client.sendReplyMessage(msg_id, to, "Surah terlalu panjang")
                                    else:
                                        client.sendReplyMessage(msg_id, to, "Quran hanya 114 surah")
                                except Exception as error:
                                        client.sendReplyMessage(msg_id, to, "error\n"+str(error))
                                #logError(error)
                                
                            elif cmd.startswith("notify "):
                                  data = cmd.replace("notify ","")
                                  #cl.sendNotify(to, data)
                                  notify.send(data)
                               
                            elif cmd == "raffle" or cmd == " raffle":
                                 group = client.getGroup(to)
                                 try:
                                     members = [mem.mid for mem in group.members]
                                 except:
                                     members = [mem.mid for mem in group.members]
                                 message = random.choice(members)
                                 sendMention(to, "Raffle @!\nWinner is...", [message])
                                 client.sendContact(to, message)
                                 
                            elif cmd == "raffle2" or cmd == " raffle2":
                                group = client.getGroup(to)
                                try:
                                    members = [mem.mid for mem in group.members]
                                except:
                                    members = [mem.mid for mem in group.members]
                                message = random.choice(members)
                                sendMention(to, "Raffle2 @!\n Losser...", [message])
                                client.sendContact(to, message)
                             
                            elif cmd.startswith("stealpicture"):
                            	if msg._from in Owner:
                                    if 'MENTION' in msg.contentMetadata.keys()!= None:
                                        names = re.findall(r'@(\w+)', text)
                                        mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                        mentionees = mention['MENTIONEES']
                                        lists = []
                                        for mention in mentionees:
                                            if mention["M"] not in lists:
                                                lists.append(mention["M"])
                                        for ls in lists:
                                            contact = client.getContact(ls)
                                            path = "http://dl.profile.line.naver.jp/{}".format(contact.pictureStatus)
                                            client.sendImageWithURL(to, str(path))
                                            thread1 = Thread(target=client.sendImageWithURL, args=(to, str(path)))

                            elif cmd.startswith('like '):
                            	if msg._from in Owner:
                                    try:
                                        typel = [1001,1002,1003,1004,1005,1006]
                                        key = eval(msg.contentMetadata["MENTION"])
                                        u = key["MENTIONEES"][0]["M"]
                                        a = client.getContact(u).mid
                                        s = client.getContact(u).displayName
                                        hasil = client.getHomeProfile(a)
                                        st = hasil['result']['feeds']
                                        for i in range(len(st)):
                                            test = st[i]
                                            result = test['post']['postInfo']['postId']
                                            client.likePost(str(sender), str(result), likeType=random.choice(typel))
                                            client.createComment(str(sender), str(result), 'Autolike by alfianbisma\nhttp://line.me/ti/p/~mr.sider\n\nSupport by Team DFB Bot')
                                        client.sendMessage(receiver, 'Done Like+Comment '+str(len(st))+' Post From' + str(s))
                                    except Exception as e:
                                        client.sendMessage(receiver, str(e))
                                        
                            elif 'Spam ' in msg.text:
                              if msg._from in admin:
                                txt = text.split(" ")
                                jmlh = int(txt[2])
                                teks = text.replace("Spam "+str(txt[1])+" "+str(jmlh)+" ","")
                                tulisan = jmlh * (teks+"\n")
                                if txt[1] == "on":
                                    if jmlh <= 500:
                                       for x in range(jmlh):
                                           client.sendMessage(to, teks)
                                    else:
                                       client.sendMessage(to, "Maksimal 500 SpamTeks!")
                                elif txt[1] == "off":
                                    if jmlh <= 500:
                                        client.sendmessage(to, tulisan)
                                    else:
                                        client.sendMessage(to, "Maksimal 500 SpamTeks!")
                                        
                            elif text.lower() == 'token chrome':
                                req = requests.get(url = 'https://api.eater.pw/CHROMEOS')
                                a = req.text
                                b = json.loads(a)
                                tknop = codecs.open("tkn.json","r","utf-8")
                                tkn = json.load(tknop)
                                tkn['{}'.format(msg._from)] = []
                                tkn['{}'.format(msg._from)].append({
                                    'qr': b['result'][0]['linkqr'],
                                    'tkn': b['result'][0]['linktkn']
                                    })
                                qrz = b['result'][0]['linkqr']
                                sendMentionV2(msg.to, "「 Silahkan @! Login 」\n{}\nKalo Sudah Ketik Token done Mblo".format(qrz), [msg._from])
                                with open('tkn.json', 'w') as outfile:
                                    json.dump(tkn, outfile)
                                    
                            elif text.lower() == 'token done':
                                tknop= codecs.open("tkn.json","r","utf-8")
                                tkn = json.load(tknop)
                                a = tkn['{}'.format(msg._from)][0]['tkn']
                                req = requests.get(url = '{}'.format(a))
                                b = req.text
                                contact = client.getContact(sender)
                                target = msg._from
                                ret_ = "╭═─「 Hasil Login 」"
                                ret_ += "\n├≽ Name : @!"
                                ret_ += "\n├≽ Id Line : " + client.getProfile().userid
                                ret_ += "\n├≽ Mid : {}".format(contact.mid)
                                ret_ += "\n├≽ Your Token : {}".format(b)
                               # ret_ += "\n├≽ Type Token : {}".format(tkn)['data']['{}'.format(msg._from)]['tkn'])
                                ret_ += "\n╰═─≽「 Hasil Login 」"
                                sendMention(sender, ret_, [sender])
                                sendMention(msg.to, "Cek Pm Kak @!", [sender])
                                
                            elif text.lower() == 'token ios':
                                req = requests.get(url = 'https://api.eater.pw/IOSIPAD')
                                a = req.text
                                b = json.loads(a)
                                tknop = codecs.open("tkn.json","r","utf-8")
                                tkn = json.load(tknop)
                                tkn['{}'.format(msg._from)] = []
                                tkn['{}'.format(msg._from)].append({
                                    'qr': b['result'][0]['linkqr'],
                                    'tkn': b['result'][0]['linktkn']
                                    })
                                qrz = b['result'][0]['linkqr']
                                sendMention(msg.to, "「 Silahkan @! Login 」\n{}\nKalo Sudah Ketik Token done Mblo".format(qrz), [msg._from])
                                with open('tkn.json', 'w') as outfile:
                                    json.dump(tkn, outfile)
                                    
                            elif text.lower() == 'token win':
                                req = requests.get(url = 'https://api.eater.pw/DESKTOPWIN')
                                a = req.text
                                b = json.loads(a)
                                tknop = codecs.open("tkn.json","r","utf-8")
                                tkn = json.load(tknop)
                                tkn['{}'.format(msg._from)] = []
                                tkn['{}'.format(msg._from)].append({
                                    'qr': b['result'][0]['linkqr'],
                                    'tkn': b['result'][0]['linktkn']
                                    })
                                qrz = b['result'][0]['linkqr']
                                sendMention(msg.to, "「 Silahkan @! Login 」\n{}\nKalo Sudah Ketik Token done Mblo".format(qrz), [msg._from])
                                with open('tkn.json', 'w') as outfile:
                                    json.dump(tkn, outfile)
                                    
                            elif text.lower() == 'token mac':
                                req = requests.get(url = 'https://api.eater.pw/DESKTOPMAC')
                                a = req.text
                                b = json.loads(a)
                                tknop = codecs.open("tkn.json","r","utf-8")
                                tkn = json.load(tknop)
                                tkn['{}'.format(msg._from)] = []
                                tkn['{}'.format(msg._from)].append({
                                    'qr': b['result'][0]['linkqr'],
                                    'tkn': b['result'][0]['linktkn']
                                    })
                                qrz = b['result'][0]['linkqr']
                                sendMention(msg.to, "「 Silahkan @! Login 」\n{}\nKalo Sudah Ketik Token done Mblo".format(qrz), [msg._from])
                                with open('tkn.json', 'w') as outfile:
                                    json.dump(tkn, outfile)
                                    
                            elif text.lower() == 'token win10':
                                req = requests.get(url = 'https://api.eater.pw/WIN10')
                                a = req.text
                                b = json.loads(a)
                                tknop = codecs.open("tkn.json","r","utf-8")
                                tkn = json.load(tknop)
                                tkn['{}'.format(msg._from)] = []
                                tkn['{}'.format(msg._from)].append({
                                    'qr': b['result'][0]['linkqr'],
                                    'tkn': b['result'][0]['linktkn']
                                    })
                                qrz = b['result'][0]['linkqr']
                                sendMention(msg.to, "「 Silahkan @! Login 」\n{}\nKalo Sudah Ketik Token done Mblo".format(qrz), [msg._from])
                                with open('tkn.json', 'w') as outfile:
                                    json.dump(tkn, outfile)
                                    
                            elif cmd == "gift":
                                gf = "b07c07bc-fcc1-42e1-bd56-9b821a826f4f","7f2a5559-46ef-4f27-9940-66b1365950c4","53b25d10-51a6-4c4b-8539-38c242604143","a9ed993f-a4d8-429d-abc0-2692a319afde"
                                contact = client.getContact(sender)
                                client.sendGift(contact.mid, random.choice(gf), "theme")                                
                                sendMention(msg.to, "Sudah dikirim ya kak @!,giftnya", [msg._from])
                                    
                            elif ("Clkick " in msg.text):
                              if wait["selfbot"] == True:
                                if msg._from in Owner:
                                   key = eval(msg.contentMetadata["MENTION"])
                                   key["MENTIONEES"][0]["M"]
                                   targets = []
                                   for x in key["MENTIONEES"]:
                                        targets.append(x["M"])
                                   for target in targets:
                                       if target not in Bots:
                                           try:
                                               client.kickoutFromGroup(msg.to, [target])
                                           except:
                                               pass
                                               
                            elif cmd == "kickall" or text.lower() == 'kickall':
                               if msg._from not in Owner:
                                  try:
                                      client.sendReplyMessage(msg.id, to, "Hayo mau ngapain 😠")
                                      client.kickoutFromGroup(msg.to,[msg._from])
                                      client.sendMessage(msg.to, "Mampus kekick, nakal si")
                                  except:
                                      try:
                                          client.kickoutFromGroup(msg.to,[msg._from])
                                      except:
                                          pass
                                      
                            elif cmd == "nuke" or text.lower() == 'nuke':
                               if msg._from not in Owner:
                                  try:
                                      client.sendReplyMessage(msg.id, to, "Hayo mau ngapain 😠")
                                      client.kickoutFromGroup(msg.to,[msg._from])
                                      client.sendMessage(msg.to, "Mampus kekick, nakal si")
                                  except:
                                      try:
                                          client.kickoutFromGroup(msg.to,[msg._from])
                                      except:
                                          pass
                                      
                            elif cmd == "kick on" or text.lower() == 'kick on':
                               if msg._from not in Owner:
                                  try:
                                      client.sendReplyMessage(msg.id, to, "Hayo mau ngapain 😠")
                                      client.kickoutFromGroup(msg.to,[msg._from])
                                      client.sendMessage(msg.to, "Mampus kekick, nakal si")
                                  except:
                                      try:
                                          client.kickoutFromGroup(msg.to,[msg._from])
                                      except:
                                          pass
                                    
# Pembatas Script #
# Pembatas Script #
                        if text.lower() == "mykey":
                          if msg._from in Owner:
                            client.sendMessage(to, "KeyCommand Saat ini adalah [ {} ]".format(str(settings["keyCommand"])))
                            
                        elif text.lower() == "setkey on":
                          if msg._from in Owner:
                            settings["setKey"] = True
                            client.sendMessage(to, "Berhasil mengaktifkan setkey")
                            
                        elif text.lower() == "setkey off":
                          if msg._from in Owner:
                            settings["setKey"] = False
                            client.sendMessage(to, "Berhasil menonaktifkan setkey")                                               
# Pembatas Script #
                    elif msg.contentType == 1:
                        if to in settings["image"]["imagetomis"]:
                            client.sendReplyMessage(msg.id,to, "Downloading...")
                            path = uploadImage(msg_id)
                            alep = change(path)
                            alep1 = settings['text1']
                            alep2 = settings['text2']
                            alep3 = settings['text3']
                            alepan = "http://ari-api.herokuapp.com/missing?text="+alep1+"&text2="+alep2+"&text3="+alep3+"&url="+alep
                            client.sendImageWithURL(to, alepan)
                            settings["image"]["imagetomis"].remove(to)
                        if settings["addPict"]["status"] == True:
                            with open('image.json','r') as fp:
                                images = json.load(fp)
                            images[settings["addPict"]["name"]] = client.downloadObjectMsg(msg_id)
                            f = codecs.open('image.json','w','utf-8')
                            json.dump(images, f, sort_keys=True, indent=4, ensure_ascii=False)
                            client.sendMessage(to, "Images {} added to list".format(str(settings["addPict"]["name"])))
                            settings["addPict"]["status"] = False
                            settings["addPict"]["name"] = ""
                        if settings['changeProfileVideo']['status'] == True and sender == clientMid:
                            path = client.downloadObjectMsg(msg_id)
                            if settings['changeProfileVideo']['stage'] == 1:
                                settings['changeProfileVideo']['picture'] = path
                                client.sendMessage(to, "Send Picture !!")
                                settings['changeProfileVideo']['stage'] = 2
                            elif settings['changeProfileVideo']['stage'] == 2:
                                settings['changeProfileVideo']['picture'] = path
                                changeProfileVideo(to)
                                client.sendMessage(to, "Succes Check Your Picture Profile !! ")

                    elif msg.contentType == 1:
                        if settings["changePictureProfile"] == True:
                            path = client.downloadObjectMsg(msg_id)
                            settings["changePictureProfile"] = False
                            client.updateProfilePicture(path)
                            client.sendMessage(to, "Berhasil mengubah foto profile")
                        if msg.toType == 2:
                            if to in settings["changeGroupPicture"]:
                                path = client.downloadObjectMsg(msg_id)
                                settings["changeGroupPicture"].remove(to)
                                client.updateGroupPicture(to, path)
                                client.sendMessage(to, "Berhasil mengubah foto group")

                    elif msg.contentType == 2:
                        if settings['changeProfileVideo']['status'] == True and sender == clientMid:
                            path = client.downloadObjectMsg(msg_id)
                            if settings['changeProfileVideo']['stage'] == 1:
                              settings['changeProfileVideo']['video'] = path
                              client.sendMessage(to, "Send Picture !!")
                              settings['changeProfileVideo']['stage'] = 2 
                            elif settings['changeProfileVideo']['stage'] == 2:
                                settings['changeProfileVideo']['video'] = path
                                changeProfileVideo(to)
                   
                    elif msg.contentType == 7:
                        if settings["addSticker"]["status"] == True:
                                with open('sticker.json','r') as fp:
                                    stickers = json.load(fp)
                                    if 'STKOPT' in msg.contentMetadata:
                                        stickers[settings["addSticker"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                                        stickers[settings["addSticker"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                                        stickers[settings["addSticker"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                                        stickers[settings["addSticker"]["name"]]["STKOPT"] = msg.contentMetadata['STKOPT']
                                    else:
                                        stickers[settings["addSticker"]["name"]]["STKVER"] = msg.contentMetadata["STKVER"]
                                        stickers[settings["addSticker"]["name"]]["STKID"] = msg.contentMetadata["STKID"]
                                        stickers[settings["addSticker"]["name"]]["STKPKGID"] = msg.contentMetadata["STKPKGID"]
                                    f = codecs.open('sticker.json','w','utf-8')
                                    json.dump(stickers, f, sort_keys=True, indent=4, ensure_ascii=False)
                                    client.sendReplyMessage(msg.id,to, "Stickers {} added to list!".format(str(settings["addSticker"]["name"])))
                                    settings["addSticker"]["status"] = False
                                    settings["addSticker"]["name"] = ""

                        if settings["checkSticker"] == True:
                            stk_id = msg.contentMetadata['STKID']
                            stk_ver = msg.contentMetadata['STKVER']
                            pkg_id = msg.contentMetadata['STKPKGID']
                            ret_ = "╭──「 Sticker Info 」"
                            ret_ += "\n├≽ STICKER ID : {}".format(stk_id)
                            ret_ += "\n├≽ STICKER PACKAGES ID : {}".format(pkg_id)
                            ret_ += "\n├≽ STICKER VERSION : {}".format(stk_ver)
                            ret_ += "\n├≽ STICKER URL : line://shop/detail/{}".format(pkg_id)
                            ret_ += "\n╰──「 Finish 」"
                            client.sendMessage(to, str(ret_))
                            
                    elif msg.contentType == 16:
                        if settings["checkPost"] == True:
                            try:
                                ret_ = "╭──「 Details Post 」"
                                if msg.contentMetadata["serviceType"] == "GB":
                                    contact = client.getContact(sender)
                                    auth = "\n├≽ Penulis : {}".format(str(contact.displayName))
                                else:
                                    auth = "\n├≽ Penulis : {}".format(str(msg.contentMetadata["serviceName"]))
                                purl = "\n├≽ URL : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                                ret_ += auth
                                ret_ += purl
                                if "mediaOid" in msg.contentMetadata:
                                    object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                                    if msg.contentMetadata["mediaType"] == "V":
                                        if msg.contentMetadata["serviceType"] == "GB":
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                            murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                                        else:
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                            murl = "\n├≽ Media URL : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                                        ret_ += murl
                                    else:
                                        if msg.contentMetadata["serviceType"] == "GB":
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                        else:
                                            ourl = "\n├≽ Objek URL : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                    ret_ += ourl
                                if "stickerId" in msg.contentMetadata:
                                    stck = "\n├≽ Stiker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                                    ret_ += stck
                                if "text" in msg.contentMetadata:
                                    text = "\n├≽ Tulisan : {}".format(str(msg.contentMetadata["text"]))
                                    ret_ += text
                                ret_ += "\n╰──「 Finish 」"
                                client.sendMessage(to, str(ret_))
                            except:
                                client.sendMessage(to, "Post tidak valid")
            except Exception as error:
                logError(error)
                traceback.print_tb(error.__traceback__)
                
        if op.type == 25 or op.type == 26:
            print ('[25/26] NOTIFED RECIVED MESSAGE')
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 0:
                 if msg.toType != 0 and msg.toType == 2:            
                  if 'MENTION' in msg.contentMetadata.keys()!= None:
                    names = re.findall(r'@(\w+)', text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    for mention in mentionees:
                      if clientMID in mention["M"]:
                        if client.getProfile().mid in mention["M"]:
                          if to not in tagme['ROM']:
                            tagme['ROM'][to] = {}
                          if sender not in tagme['ROM'][to]:
                            tagme['ROM'][to][sender] = {}
                          if 'msg.id' not in tagme['ROM'][to][sender]:
                            tagme['ROM'][to][sender]['msg.id'] = []
                          if 'waktu' not in tagme['ROM'][to][sender]:
                            tagme['ROM'][to][sender]['waktu'] = []
                          tagme['ROM'][to][sender]['msg.id'].append(msg.id)
                          tagme['ROM'][to][sender]['waktu'].append(msg.createdTime)
                
        if op.type == 26 or op.type == 25:
            try:
                print ("[ 26 ] RECIEVE MESSAGE")
                msg = op.message
                text = msg.text
                msg_id = msg.id
                receiver = msg.to
                sender = msg._from
                if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != client.profile.mid:
                            to = sender
                        else:
                            to = receiver
                    elif msg.toType == 1:
                        to = receiver
                    elif msg.toType == 2:
                        to = receiver
                    if settings["autoRead"] == True:
                        client.sendChatChecked(to, msg_id)
                    if to in read["readPoint"]:
                        if sender not in read["ROM"][to]:
                            read["ROM"][to][sender] = True
                    if sender in settings["mimic"]["target"] and settings["mimic"]["status"] == True and settings["mimic"]["target"][sender] == True:
                        text = msg.text
                        if text is not None:
                            client.sendMessage(msg.to,text)
                    if msg.contentType == 0 and sender not in clientMid and msg.toType == 2:
                      if 'MENTION' in msg.contentMetadata.keys() != None:
                          names = re.findall(r'@(\w+)', msg.text)
                          mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                          mentionees = mention['MENTIONEES']
                          for mention in mentionees:
                              if mention['M'] == clientMid:
                                  if to not in settings["userMentioned"]:
                                      settings["userMentioned"][to] = {}
                                  if sender not in settings["userMentioned"][to]:
                                      settings["userMentioned"][to][sender] = {}
                                  if "msg.id" not in settings["userMentioned"][to][sender]:
                                      settings["userMentioned"][to][sender]["msg.id"] = []
                                  if "waktu" not in settings["userMentioned"][to][sender]:
                                      settings["userMentioned"][to][sender]["waktu"] = []
                                  settings["userMentioned"][to][sender]["msg.id"].append(msg.id)
                    if settings["unsendMessage"] == True:
                        try:
                            msg = op.message
                            if msg.toType == 0:
                                client.log("[{} : {}]".format(str(msg._from), str(msg.text)))
                            else:
                                client.log("[{} : {}]".format(str(msg.to), str(msg.text)))
                                msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                        except Exception as error:
                            logError(error)
                    if msg.contentType == 1:
                       if settings["unsendMessage"] == True:
                           try:
                              path = client.downloadObjectMsg(msg_id, saveAs="client.png")
                              msg_dict[msg.id] = {"from":msg._from,"image":path,"createdTime": msg.createdTime}
                              with open("Log_data.json", "w") as fp:
                                json.dump(msg_dict, fp, sort_keys=True, indent=4)
                           except Exception as e:
                             print (e)
                    if msg.contentType == 2:
                       if settings["unsendMessage"] == True:
                           try:
                              path = client.downloadObjectMsg(msg_id, saveAs="rian.mp4")
                              msg_dict[msg.id] = {"from": msg._from,"video":path,"createdTime": msg.createdTime}
                              with open("Log_data.json", "w") as fp:
                                json.dump(msg_dict, fp, sort_keys=True, indent=4)
                           except Exception as e:
                               print (e)
                    if msg.contentType == 7:
                       if settings["unsendMessage"] == True:
                           try:
                              sticker = msg.contentMetadata["STKID"]
                              link = "http://dl.stickershop.line.naver.jp/stickershop/v1/sticker/{}/android/sticker.png".format(sticker)
                              msg_dict[msg.id] = {"from":msg._from,"sticker":link,"createdTime": msg.createdTime}
                              with open("Log_data.json", "w") as fp:
                                json.dump(msg_dict, fp, sort_keys=True, indent=4)
                           except Exception as e:
                             print (e)                          
                    if msg.contentType == 0:
                        if text is None:
                            return
                        if "/ti/g/" in msg.text.lower():
                            if settings["autoJoinTicket"] == True:
                                link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                links = link_re.findall(text)
                                n_links = []
                                for l in links:
                                    if l not in n_links:
                                        n_links.append(l)
                                for ticket_id in n_links:
                                    group = client.findGroupByTicket(ticket_id)
                                    if len(group.members) <= 5:
                                    	client.sendMessage(to, "Mohon Maaf Kak Anggota Group {} Kurang Dari 5 Member".format(group.name))
                                    	return
                                    else:
                                    	client.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    	client.sendMessage(to, "Succes Joined To Group %s " % str(group.name))
                            else:
                            	client.sendMessage(to, "Tidak Dapat Masuk Ke Group {} \nAtau Saya Sudah Berada Disana".format(group.name))
                        if 'MENTION' in msg.contentMetadata.keys()!= None:
                            names = re.findall(r'@(\w+)', text)
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = []
                            for mention in mentionees:
                                if clientMid in mention["M"]:
                                    if settings["autoRespon"] == True:
                                        sendMention(sender, "Oi Asw @!,jangan main tag tag", [sender])
                                    break
            except Exception as error:
                logError(error)
                traceback.print_tb(error.__traceback__)
                
        if op.type == 65:
            print ("[ 65 ] NOTIFIED DESTROY MESSAGE")
            if settings["unsendMessage"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                            contact = client.getContact(msg_dict[msg_id]["from"])
                            if contact.displayNameOverridden != None:
                                name_ = contact.displayNameOverridden
                            else:
                              if "text" in msg_dict[msg_id]:
                                name_ = contact.displayName
                                ret_ = " 「 Pesan Dihapus 」 "
                                ret_ += "\n• Pengirim : {}".format(str(contact.displayName),str(contact.mid))
                                ret_ += "\n• Waktu : {}".format(str(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"]))))
                                ret_ += "\n• Type : Text "
                                ret_ += "\n• Text : {}".format(str(msg_dict[msg_id]["text"]))
                                client.sendMessage(at, str(ret_), {'AGENT_NAME': 'Unsend Message','AGENT_LINK': 'http://line.me/ti/p/~bacbac.id','AGENT_ICON': "http://dl.profile.line-cdn.net{}".format(str(contact.picturePath))})
                                client.sendSticker(at, '1482011','17822843')
                                del msg_dict[msg_id]
                              else:
                                if "sticker" in msg_dict[msg_id]:
                                  name_ = contact.displayName
                                  ret_ = " 「 Pesan Dihapus 」"
                                  ret_ += "\n• Pengirim : {}".format(str(contact.displayName),str(contact.mid))
                                  ret_ += "\n• Waktu : {}".format(str(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"]))))
                                  ret_ += "\n• Link Sticker : {} ".format(str(msg_dict[msg_id]["sticker"]))
                                  ret_ += "\n• Type : Sticker"
                                  client.sendMessage(at, str(ret_), {'AGENT_NAME': 'Unsend Message','AGENT_LINK': 'http://line.me/ti/p/~bacbac.id','AGENT_ICON': "http://dl.profile.line-cdn.net{}".format(str(contact.picturePath))})
                                  client.sendImageWithURL(at, msg_dict[msg_id]["sticker"])
                                  del msg_dict[msg_id]
                                else:
                                  if "image" in msg_dict[msg_id]:
                                    name_ = contact.displayName
                                    ret_ = " 「 Pesan Dihapus 」 "
                                    ret_ += "\n• Pengirin : {}".format(str(contact.displayName),str(contact.mid))
                                    ret_ += "\n• Waktu : {}".format(str(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"]))))
                                    ret_ += "\n• Link Image : Not Found ."
                                    ret_ += "\n• Type : Image"
                                    client.sendMessage(at, str(ret_), {'AGENT_NAME': 'Unsend Message','AGENT_LINK': 'http://line.me/ti/p/~bacbac.id','AGENT_ICON': "http://dl.profile.line-cdn.net{}".format(str(contact.picturePath))})
                                    client.sendImage(at, "client.png")
                                    del msg_dict[msg_id]
                                  else:
                                    if "video" in msg_dict[msg_id]:
                                      name_ = contact.displayName
                                      ret_ = " 「 Pesan Dihapus 」 "
                                      ret_ += "\n• Pengirim : {}".format(str(contact.displayName),str(contact.mid))
                                      ret_ += "\n• Waktu : {}".format(str(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"]))))
                                      ret_ += "\n• Link Video  : Not Found ."
                                      ret_ += "\n• Type  : Video"
                                      client.sendMessage(at, str(ret_), [contact.mid])
                                      client.sendVideo(at, "rian.mp4")
                                      del msg_dict[msg_id]
                        else:
                            client.sendMessage(at,"SentMessage .cancelled,But I didn't have log data.\nSorry > <")
                except Exception as error:
                    logError(error)
                    traceback.print_tb(error.__traceback__)
                
        if op.type == 55:
            print ("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in read['readPoint']:
                    if op.param2 in read['readMember'][op.param1]:
                        pass
                    else:
                        read['readMember'][op.param1] += op.param2
                    read['ROM'][op.param1][op.param2] = op.param2
                else:
                   pass
            except Exception as error:
                logError(error)
                traceback.print_tb(error.__traceback__)
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)

while True:
    try:
        delete_log()
        delExpire()
        ops = clientPoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                clientBot(op)
                clientPoll.setRevision(op.revision)
    except Exception as error:
        logError(error)
        
def atend():
    print("Saving")
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
    print("BYE")
atexit.register(atend)
